/**
 * Created by vasil_000 on 09.02.2018.
 */
public class Boat extends Movable{

    River river;

    public Boat(int x, int y, River river){
        super(x,y,'B');
        this.river = river;
    }

    public void move() {
        int[] nearPos = river.getNearestTorpedo(pos);

        int[] nextPos = getNextPos(nearPos);

        if(river.isPosFree(nextPos)) pos = nextPos;
    }

    private int[] getNextPos(int[] nearPos){
        int[] nextPos = new int[2];

        for(int i = 0; i < nextPos.length; ++i){

            nextPos[i] = nearPos[i] - pos[i];

            if(nextPos[i]>0) nextPos[i] = 1;
            if(nextPos[i]<0) nextPos[i] = -1;

            nextPos[i] = pos[i] + nextPos[i];
        }

        return nextPos;
    }
}
