/**
 * Created by vasil_000 on 09.02.2018.
 */
public class Bridge {
    private String rep;

    public Bridge(String r){
        rep = r;
    }

    public String getRep() {
        return rep;
    }

    public boolean isHit(int col){
        return rep.charAt(col) == 'P';
    }
}
