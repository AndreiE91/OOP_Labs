import java.util.Scanner;

/**
 * Created by vasil_000 on 09.02.2018.
 */
public class Main {
    public static void main(String[] args) {
        oop.Bombs.asdf();

        River river = new River();

        System.out.println(river.toString());

        Scanner sc = new Scanner(System.in);

        while(river.hasTorpedoes() && !river.isBridgeHit()){

            System.out.println("Please press Enter\n");
            sc.nextLine();

            river.doStep();

            System.out.println(river.toString());
        }

        System.out.println("Game ended.");
        if(river.isBridgeHit()) System.out.println("Bridge hitted.");
        else System.out.println("No more torpedoes.");
    }
}
