import java.util.Arrays;

public abstract class Movable {

    protected int[] pos;
    protected char symbol;

    public Movable(int x,int y,char symbol){
        this.symbol = symbol;

        pos = new int[2];
        pos[0] = x; pos[1] = y;
    }

    public char getSymbol(){
        return symbol;
    }

    public int[] getPos(){
        return pos;
    }

    public int getX(){return pos[0];}
    public int getY(){return pos[1];}

    abstract void move();
}
