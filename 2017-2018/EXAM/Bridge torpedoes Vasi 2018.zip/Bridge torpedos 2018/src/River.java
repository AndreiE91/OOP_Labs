import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;


/**
 * Created by vasil_000 on 09.02.2018.
 */
public class River {
    char[][] water;
    List<Torpedo> torpedos;
    List<Boat> boats;
    int[] torpedosToLaunch;
    Bridge bridge;
    private boolean bridgeHitted = false;

    public River(){
        water = new char[Utils.RIVER_LINES][Utils.RIVER_COLUMNS];
        torpedos = new LinkedList<>();
        boats = new LinkedList<>();

        torpedosToLaunch = new int[Utils.RIVER_COLUMNS];
        for(int i = 0; i < torpedosToLaunch.length; ++i) torpedosToLaunch[i] = 0;

        readBoats();
        readTorpedos();
        readBridge();

        updateRepresentation();
    }

    public boolean isBridgeHit(){
        return bridgeHitted;
    }

    public boolean hasTorpedoes(){
        for(int i: torpedosToLaunch)
            if(i>0) return true;

        return !torpedos.isEmpty();
    }

    public void doStep(){
        moveTorpedoes();
        addNewTorpedoes();

        killBoats();

        if(bridgeHitted) return;

        removeTorpedos();

        moveBoats();


        updateRepresentation();
    }

    public int[] getNearestTorpedo(int[] pos){
        int[] near = new int[2];
        int minDist = Utils.RIVER_COLUMNS + Utils.RIVER_LINES;

        for(Torpedo t:torpedos) {
            if(Math.max( Math.abs(pos[0] - t.getX()), Math.abs(pos[1] - t.getY())) < minDist) {
                minDist = Math.max( Math.abs(pos[0] - t.getX()), Math.abs(pos[1] - t.getY()));
                near = t.getPos();
            }
        }

        if(minDist == Utils.RIVER_COLUMNS + Utils.RIVER_LINES) near = pos;

        return near;
    }

    public boolean isPosFree(int[] pos){
        for(Boat b:boats)
            if(pos[0] == b.getX() && pos[1] == b.getY()) return false;

        return true;
    }


    private void moveTorpedoes(){
        for(Torpedo t:torpedos) t.move();
    }

    private void addNewTorpedoes(){
        for(int i = 0; i < torpedosToLaunch.length; ++i)
            if(torpedosToLaunch[i] > 0){
                torpedosToLaunch[i]--;
                 torpedos.add(new Torpedo(0,i));
            }
    }

    private void killBoats(){
        for(Iterator<Torpedo> it = torpedos.iterator(); it.hasNext();){
            Torpedo t = it.next();

            out:for(Iterator<Boat> it2 = boats.iterator(); it2.hasNext();){
                Boat b = it2.next();

                for(int[] pos: t.getVisited()){
                    if(b.getX() == pos[0] && b.getY() == pos[1]){
                        it2.remove();
                        it.remove();
                        break out;
                    }
                }
            }
        }

        for(Torpedo t: torpedos)
            for(int[] pos: t.getVisited())
                if(pos[0] == water.length - 1 && bridge.isHit(pos[1]))
                    bridgeHitted = true;
    }

    private void moveBoats(){

        int[] colT = getTorpedoExistence();

        for(Boat b: boats)
            if(colT[b.getY()] == 0)
                b.move();

    }

    private int[] getTorpedoExistence(){
        int a[] = new int[Utils.RIVER_COLUMNS];
        for(int i = 0; i < a.length; ++i) a[i] = 0;

        for(Torpedo t: torpedos)
            a[t.getY()]++;

        return a;
    }

    private void removeTorpedos(){
        for(Iterator<Torpedo> it = torpedos.iterator(); it.hasNext();){
            Torpedo t = it.next();
            if(t.getX() >= water.length) it.remove();
        }
    }

    private void initWater(){
        for(int i = 0; i < water.length; ++i)
            for(int j = 0; j < water[i].length; ++j)
                water[i][j] = '.';
    }

    private void updateRepresentation(){
        initWater();

        for(Torpedo t:torpedos) water[t.getX()][t.getY()] = t.getSymbol();
        for(Boat b:boats) water[b.getX()][b.getY()] = b.getSymbol();

        water[water.length - 1] = bridge.getRep().toCharArray();

    }

    @Override
    public String toString(){
        String res = "";
        for(char[] c:water)
            res = res + "\n" + new String(c);

        return res;
    }

    private void readBoats(){
        int[][] a = oop.Bombs.readBoats();

        for(int i = 0; i<a.length; ++i)
        {
            boats.add(new Boat(a[i][0],a[i][1],this));
        }
    }

    private void readTorpedos(){
        int[][] a = oop.Bombs.readTorpedoes();

        for(int i = 0; i < a.length; ++i)
            torpedosToLaunch[a[i][1]] = a[i][0];
    }

    private void readBridge()
    {
        int[] a = oop.Bombs.readBridge();
        char[] c = new char[Utils.RIVER_COLUMNS];

        for(int i = 0; i < c.length; ++i) c[i] = '=';
        for(int i:a) c[i] = 'P';

        bridge = new Bridge(new String(c));
    }
}
