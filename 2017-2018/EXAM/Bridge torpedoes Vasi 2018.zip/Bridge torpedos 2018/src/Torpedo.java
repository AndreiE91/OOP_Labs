import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Created by vasil_000 on 09.02.2018.
 */
public class Torpedo extends Movable{

    private static Random rnd = new Random();
    private static int[] directions = {-1,0,1};
    private List<int[]> visited;

    public Torpedo(int x,int y){
        super(x,y,'T');
        visited = new ArrayList<>();
        visited.add(pos);
    }

    public List<int[]> getVisited(){
        return visited;
    }

    private void addToVisited(int[] pos){
        int[] x = {pos[0],pos[1]};
        visited.add(x);
    }

    public void move(){

        visited.clear();
        addToVisited(pos);

        int dist = rnd.nextInt(Utils.TORPEDO_MOVE) + 1;
        int dir = directions[rnd.nextInt(directions.length)];

        if(pos[1] + dist*dir >= Utils.RIVER_COLUMNS || pos[1] + dist*dir <0) dir = 0;

        for(int i = 1; i <= dist; ++i){
            pos[0]++;
            pos[1] += dir;

            addToVisited(pos);
        }

    }
}
