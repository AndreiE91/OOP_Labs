public class Utils {
    public static final int RIVER_LINES = 15;
    public static final int RIVER_COLUMNS = 85;
    public static final int TORPEDO_MOVE = 2;

}
