package oop;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.NoSuchElementException;
import java.io.FileNotFoundException;
import java.io.File;
import java.io.FileReader;

public class Bombs {

    private static int[][] torpedoes;
    private static int[][] boats;
    private static int[] bridge;
    private static Scanner sc;
    private static List <int[]> b = new ArrayList<>();


    public static int[][] readTorpedoes() {
        return torpedoes;
    }

    public static int[][] readBoats() {
        return boats;
    }

    public static int[] readBridge() {
        return bridge;
    }

    public static void asdf() {
        File f = null;
        FileReader fr = null;

        try {
            f = new File("config.dat");
        } catch (NullPointerException e) {
            System.out.println("No config.dat");
            System.exit(1);
        }
        try {
            fr = new FileReader(f);
        } catch (FileNotFoundException e) {
            System.out.println("Nu am config.dat");
            System.exit(1);
        }
        //         catch (IOException e)
        //         {
        //             System.out.println("Eroare I/E");
        //             System.exit(1);
        //         }
        sc = new Scanner(fr);
        try {
            readConfig();
        } catch (NoSuchElementException e) {
            System.out.println("Bad configuration");
            System.exit(1);
        } catch (IllegalStateException e) {
            System.out.println("Input error");
            System.exit(2);
        }
    }

    private static void readConfig() throws NoSuchElementException, IllegalStateException {
        readTorpedos(sc);
        for (int i = 0; i < 14; i++) {
            readWater(sc, i);
        }
        readBridge(sc);
    }

    private static void readTorpedos(Scanner sc) throws NoSuchElementException, IllegalStateException {
        String line = sc.nextLine();
        List <int[]> t = new ArrayList<>();

        int i = 0;
        while (i < line.length()) {
            while (Character.isWhitespace(line.charAt(i))) i++; // skip spaces
            if (Character.isDigit(line.charAt(i))) // beginning of whirlpool column spec
            {
                int nbWhirlpools = Integer.parseInt(line.substring(i, i + 1));
                i += 2; // skip '('
                int k = i;
                while (line.charAt(k) != ')') k++; // look for ')'
                int colWhirlpools = Integer.parseInt(line.substring(i, k));
                int[] x = {nbWhirlpools, colWhirlpools};
                t.add(x);
                i = k + 2; // skip ')'
            }
        }

        torpedoes = new int[t.size()][];
        for(int j = 0; j < torpedoes.length; ++j)
            torpedoes[j] = t.get(j);
    }

    private static void readWater(Scanner sc, int row) throws NoSuchElementException, IllegalStateException {
        String line = sc.nextLine();

        for (int i = 0; i < line.length(); i++) {
            if (line.charAt(i) == 'B') {
                int[] x = {row,i};
                b.add(x);
            }
        }

        boats = new int[b.size()][];
        for(int i = 0; i < boats.length; ++i)
            boats[i] = b.get(i);
    }

    private static void readBridge(Scanner sc) throws NoSuchElementException, IllegalStateException {
        String s = sc.nextLine();
        List<Integer> v = new ArrayList<>();

        for(int i = 0; i < s.length(); ++i)
            if(s.charAt(i) == 'P') v.add(i);

        bridge = new int[v.size()];
        for(int i = 0; i<bridge.length; ++i)
            bridge[i] = v.get(i);

    }

}
