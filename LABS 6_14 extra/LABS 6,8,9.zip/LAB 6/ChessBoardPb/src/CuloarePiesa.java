public enum CuloarePiesa {
    ALB,
    NEGRU
}
