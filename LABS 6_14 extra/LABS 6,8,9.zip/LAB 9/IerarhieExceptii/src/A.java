public class A {
    public void myMethod() throws MyException1{
        throw new MyException1();
    }
}
