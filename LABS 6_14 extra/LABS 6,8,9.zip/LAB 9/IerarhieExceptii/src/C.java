public class C extends B{
    @Override
    public void myMethod() throws MyException3 {
        throw new MyException3();
    }
}
