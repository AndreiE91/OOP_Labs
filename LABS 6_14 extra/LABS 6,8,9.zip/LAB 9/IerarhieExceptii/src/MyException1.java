public class MyException1 extends Exception{
}
