public class MyException2 extends MyException1{
}
