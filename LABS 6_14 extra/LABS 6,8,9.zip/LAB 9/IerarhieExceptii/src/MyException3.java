public class MyException3 extends MyException2{
}
