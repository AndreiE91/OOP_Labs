
/**
 * Write a description of class InitDefault here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class InitDefault
{
    // instance variables - replace the example below with your own
    private int x;
    private byte y;
    private char z;
    private short u;
    private long v;
    private float f;
    private double d;
    private String s;
    public void method()
    {
        int x;
        byte y;
        char z;
        short u;
        long v;
        float f;
        double d;
        String s;
         System.out.println("int x=" + x +
//         " byte y=" + y+
//         " char z="+z+
//         " short u="+u+
//         " long v="+v+
//         " float f="+f+
//         " double d="+d +
         " String s="+s);
        return;
    }
}
