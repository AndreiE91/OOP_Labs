
/**
 * Write a description of class Person here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Person
{
    // instance variables - replace the example below with your own
    private int age;

    /**
     * Constructor for objects of class Person
     */
    private Person(int age)
    {
        this.age = age;
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public int getAge()
    {
        // put your code here
        return age;
    }
    public static Person create(int age) 
    { //exemplu: metod? de fabricare
        if (age < 0) throw new IllegalArgumentException("Too young!");
        else return new Person(age);
    }
    public static void main()
    {
        Person p = null;
        try
        {
            p = new Person(-2);
        }
        catch (IllegalArgumentException e)
        {
            System.out.println(p + " " + e);
        }
        System.out.println(p);
    }

}
