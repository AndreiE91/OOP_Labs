
/**
 * Write a description of class StaticStuff here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StaticStuff
{
    private static double staticDouble;
    private static String staticString;
    int x;
    public StaticStuff()
    {
        this(0);
    }
    public StaticStuff(int x)
    {
        this.x = x;
    }
    public String toString()
    {
        return "x=" + x + " staticDouble=" + staticDouble +
        " staticString=" + staticString;
    }
    public static void main()
    {
        StaticStuff s1, s2;
        s1 = new StaticStuff();
        s2 = new StaticStuff(2);
        s1.staticDouble = 3.7;
        System.out.println( s1.staticDouble );
        System.out.println( s2.staticDouble );
        s1.staticString = "abc";
        s2.staticString = "xyz";
        System.out.println( s1 );
        System.out.println( s2 );
    }
}


