
/**
 * Write a description of class testCmpObj here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TestCmpObj
{
    int x;
    public TestCmpObj(int a)
    {
       x = a;
    }
    public boolean equals(TestCmpObj o)
    {
        if (this.x == o.x) return true;
        else return false;
    }
    public static void main(String args[])
    {
        TestCmpObj o1 = new TestCmpObj(10);
        TestCmpObj o2 = new TestCmpObj(10);
        if (o1 == o2)
            System.out.println("10=10 :-)");
        else
            System.out.println("10!=10 :-)");
        if (o1.equals(o2))
            System.out.println("10 equals 10 :-)");
        else
            System.out.println("10 does not equal 10 :-)");
        String s1 = "aaa";
        String s2 = "aaa";
        if (s1 == s2)
            System.out.println("aaa=aaa :-)");
        else
            System.out.println("aaa!=aaa :-)");
        

    }
}
