
/**
 * Write a description of class OverFlow here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class OverFlow
{
    // instance variables - replace the example below with your own
    public static void main()
    {
        int a = 323232332;
        long b = 323232332L;

        float f = 3e38f;
        double d = 3e300d;
        System.out.println("a^2=" + (a * a));
        System.out.println("b^2=" + (b * b));
        System.out.println("b^3=" + (b * b * b));
        if (f * 1000 == Float.POSITIVE_INFINITY)
            System.out.println("Float.POSITIVE_INFINITY");
        System.out.println("f * 1000 =" + (f * 1000f));
        System.out.println("f + d =" + (f + d));
        System.out.println("sqrt(-2)=" + Math.sqrt(-2.0));
    }
}
