/**
 * Write a description of class Counter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Counter 
{
	private int number;

	/**     
	 *  Constructor. Initializes counter to zero.
	 */
	public Counter()
	{
		number = 0;
	}

	/**     
	 * @return current counter value
	 	 */
	public int getNumber()
	{
		return number;
	}

	/**     
	 * Increment counter by one
	 */
	public void increment()
	{
		number++;
	}

	/**     
	 * Reset counter to zero
	 */
	public void reset()
	{
		number = 0;
	}
}

