/**
 * Write a description of class CounterArray here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CounterArray {
	// instance variables - replace the example below with your own
	private Counter counters[];

	/**
	 * Constructor for objects of class CounterArray
	 */
	public CounterArray(int dim)
	{
		if (dim > 0)
			counters = new Counter[dim];
		else
		{
			counters = new Counter[1];
			System.out.println("Wrong dimension: " + dim
					+ " Defaulting to size 1");
		}
	}

	void setElem(int index, Counter c)
	{
		if (index >= 0 && index < counters.length)
			counters[index] = c;
	}

	void incElem(int index)
	{
		if (index >= 0 && index < counters.length && counters[index] != null)
			counters[index].increment();
	}

	int getDim()
	{
		return counters.length;
	}

	int sum()
	{
		int sum = 0;
		for (int i = 0; i < counters.length; i++)
			if (counters[i] != null)
				sum += counters[i].getNumber();
		return sum;
	}
}