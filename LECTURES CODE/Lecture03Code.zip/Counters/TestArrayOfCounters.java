import java.util.Random;

/**
 * Write a description of class TestCounterArray here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TestArrayOfCounters
{
	public static void main()
	{
		Random r = new Random();
		CounterArray t = new CounterArray(10);
		for (int i = 0; i < t.getDim(); i++)
		{
			if (r.nextInt(2) == 1)
			{
				t.setElem(i, new Counter());
				int n = r.nextInt(4);
				System.out.println("t[" + i + "]=" + n);
				while (n-- > 0)
					t.incElem(i);
			}
		}
		System.out.println("Suma valorilor contoarelor este: " + t.sum());
	}
}
