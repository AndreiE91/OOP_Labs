
/**
 * Write a description of class KmToMiles here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
// Author : Fred Swartz
import javax.swing.JOptionPane;
public class KmToMiles 
{
	private static double convertKmToMi(double kilometers) {
    	return kilometers * 0.621; // There are 0.621 miles in a kilometer.
	}
	public static void main(String[] args) {
		//... Local variables
 		String kmStr;    // String km before conversion to double.
 		double km;       // Number of kilometers.
  		double mi;       // Number of miles.
  		//... Input
  		kmStr = JOptionPane.showInputDialog(null, "Enter kilometers.");
  		km = Double.parseDouble(kmStr);
  		//... Computation
  		mi = convertKmToMi(km) ;  
  		//... Output
  		JOptionPane.showMessageDialog(null, km + " kilometers is " + mi + " miles.");
  	}
}