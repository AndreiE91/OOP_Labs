/**
 * Write a description of class TicTacToe here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TicTacToe {
    // Variabile instan??
    /* tablou bidimensional de caractere pentru board
     */
    private char[][] board;

    /** Constructor � cboard for TicTacToe
     */
    public TicTacToe()
    {
        this(3);
    }

    /** Constructor 
     */
    public TicTacToe(int size)
    {
        if (size < 3)
        {
            board = new char[3][3];
            System.out.println("Bad size (< 3). Defaulting to 3 by 3 board");
        }
        else
            board = new char[size][size];

        for (int row = 0; row < board.length; row++)
        {
            for (int col = 0; col < board[row].length; col++)
            {
                board[row][col] = '_';
            } // 
        } 
    }

    /** Pune caracterul  c pe pozi?ia [row][col]  a
     * tablei de joc dac? row, col ?i c  sunt valide
     * ?i p?tratului de la [row][col] nu i-a fost
     * atribuit? deja o valoare ( alta dec�t valoarea
     * implicit?, '_').
     * @param row rowul de pe board
     * @param col coloana de pe board
     * @param c caracter folosit la marcare
     * @return  true dac? reu?e?te, alfel false
     */
    public boolean set(int row, int col, char c)
    {
        if (row >= board.length || row < 0)
            return false;
        if (col >= board[0].length || col < 0)
            return false;
        if (board[row][col] != '_')
            return false;
        if (!(c == 'X' || c == 'O'))
            return false;
        // asser?iune: row, col, c sunt valide
        board[row][col] = c;
        return true;
    }

    /**
     * @return caracterul din pozi?ia [row][col] de pe board.
     * @param row rowul de pe board
     * @param col coloana de pe board
     */
    public char get(int row, int col)
    {
        if (row >= 0 && row < board.length && col >=0 &&
            col <= board[row].length)
            return board[row][col];
        else
        {
            System.err.println("Bad row or col in get");
            return '\u0000';
        }
    }
    public String toString()
    {
        String s= "";
        for (int row = 0; row < board.length; row++)
        {
            for (int col = 0; col < board[row].length; col++)
            {
                s += board[row][col] + " ";
            } 
            s += "\n";
        }       
        return s;
    }
    /** Tip?re?te starea tablei, d.e.
     *     _ _ _
     *     _ X O
     *     O _ X
     */
    public void print()
    {
          System.out.println(this);
    }
}

