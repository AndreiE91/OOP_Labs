/**
 * Concrete class Circle - inherits from Shape
 */
public class Circle extends Shape {
    private double r; // radius of circle
    // Constructor
    public Circle(double r)     {
        super();
        this.r = r;
    }
    // calculate area
    public double calculateArea()     {
        return  Math.PI * r * r;
    }
    // calculate perimeter
    public double calculatePerimeter()    {
        return 2.0 * Math.PI * r ;
    }
     protected void finalize() throws Throwable    {
        super.finalize();
    }
}
