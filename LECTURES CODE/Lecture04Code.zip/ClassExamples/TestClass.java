
/**
 * Write a description of class TestClass here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TestClass
{
    public static void printClassName(Object obj) {
        System.out.println(obj + " is of class " + obj.getClass().getName());
    }
    public static void main(String[] args)
    {
        Circle c = new Circle(5);
        printClassName(c);
        Class c1 = c.getClass();
        System.out.println(c1.getName()); // prints "Circle"
        Triangle t = new Triangle(7);
        printClassName(t);
        try {
            Class c2 = Class.forName("Triangle");
            System.out.println(c2.getName()); // prints "Triangle"
        }
        catch (ClassNotFoundException e) {
            System.err.println("No class for \"Triangle\"" + e.getMessage());
        }
        
    }
}
