import java.util.Scanner;

public class Date
{
    private String month; // string representation of month
    private int day; // day of  month 1..31
    private int year; //a four digit number.

    /**
     * Parameterless constructor for 1 January 1000
     */
    public Date( )  {
        month = "January";
        day = 1;
        year = 1000;
    }
    /**
     * Constructs a date form a three integer: month, day, year representation
     * @param monthInt integer number representing month 1..12
     * @param day day of  month 1..31
     * @param year a four digit number
     */
    public Date(int monthInt, int day, int year) {
        setDate(monthInt, day, year);
    }
    /**
     * @param monthString name of  month (January . December)
     * @param day day of  month 1..31
     * @param year a four digit number
     */
    public Date(String monthString, int day, int year) {
        setDate(monthString, day, year);
    }
    /**
     * Constructs a date as January 1 of year given 
     * @param year a four digit number
     */
    public Date(int year) {
        setDate(1, 1, year);
    }
    /**
     * Constructs a date from a given Date object 
     * @param aDate Date object used as source for date
    */
    public Date(Date aDate)  {
        if (aDate == null)//Not a real date.
        {
             System.out.println("Fatal Error. Null date reference");
             System.exit(0);
        }

        month = aDate.month;
        day = aDate.day;
        year = aDate.year;
    }
    /**
     * Sets  date from  given three integers representation
     * @param monthInt integer number representing month 1..12
     * @param day day of  month 1..31
     * @param year a four digit number
     */
    public void setDate(int monthInt, int day, int year) {
        if (dateOK(monthInt, day, year))
        {
            this.month = monthString(monthInt);
            this.day = day;
            this.year = year;
        }
        else
        {
            System.out.println("Fatal Error setting date");
            System.exit(0);
        }
    }
    /**
     * Sets  date from a usual representation with month as string, day and year 
     * @param monthString name of  month (January . December)
     * @param day day of  month 1..31
     * @param year a four digit number
     */
    public void setDate(String monthString, int day, int year) {
        if (dateOK(monthString, day, year))
        {
            this.month = monthString;
            this.day = day;
            this.year = year;
        }
        else
        {
            System.out.println("Fatal Error setting date");
            System.exit(0);
        }
    }
    /**
     * Sets date to January 1 of year     
     * @param year a four digit number
     */
    public void setDate(int year) {
        setDate(1, 1, year);
    }
    /**
     * Sets year of this date
     * @param year a four digit number
     */
    public void setYear(int year) {
        if ( (year < 1000) || (year > 9999) )
        {
            System.out.println("Fatal Error setting year");
            System.exit(0);
        }
        else
            this.year = year;
    }
    /**
     * Sets month of this date
     * @param monthNumber month as an integer (1..12)
     */
    public void setMonth(int monthNumber) {
        if ((monthNumber <= 0) || (monthNumber > 12))
        {
            System.out.println("Fatal Error setting month");
            System.exit(0);
        }
        else
            month = monthString(monthNumber);
    }
    /**
     * Sets day of this date
     * @param day day of  month: 1..31
     */
    public void setDay(int day) {
        if ((day <= 0) || (day > 31))
        {
            System.out.println("Fatal Error setting day");
            System.exit(0);
        }
        else
            this.day = day;
    }
    /**
     * @return integer representation of month (1..12)
     */
    public int getMonth( ) {
        if (month.equals("January"))
            return 1;
        else if (month.equals("February"))
            return 2;
        else if (month.equalsIgnoreCase("March"))
            return 3;
        else if (month.equalsIgnoreCase("April"))
            return 4;
        else if (month.equalsIgnoreCase("May"))
            return 5;
        else if (month.equals("June"))
            return 6;
        else if (month.equalsIgnoreCase("July"))
            return 7;
        else if (month.equalsIgnoreCase("August"))
            return 8;
        else if (month.equalsIgnoreCase("September"))
            return 9;
        else if (month.equalsIgnoreCase("October"))
            return 10;
        else if (month.equals("November"))
            return 11;
        else if (month.equals("December"))
            return 12;
        else
        {
            System.out.println("Fatal Error getting month number");
            System.exit(0);
            return 0; //Needed to keep  compiler happy
        }
    }
   /**
   * @return day of  month of this date
   */
    public int getDay( ) {
        return day;
    }
   /**
   * @return year of this date
   */
    public int getYear( ) {
        return year;
    }
    /**
     * @return this date as a String
     */
    public String toString( ) {
        return (month + " " + day + ", " + year);
    }
    /**
     * @return true if two dates represent  same date; false orwise
     */
    public boolean equals(Date orDate) {
        if (orDate == null)
            return false;
        else
            return ( (month.equals(orDate.month)) &&
                (day == orDate.day) && (year == orDate.year) );
    }
    /**
     * @return true if or date is earlier than this date
     */
    public boolean precedes(Date orDate) {
        return ( (year < orDate.year) ||
           (year == orDate.year && getMonth( ) < orDate.getMonth( )) ||
           (year == orDate.year && month.equals(orDate.month)
                                         && day < orDate.day) );
    }
    /**
     * Reads a date from  Console
     */
    public void readInput( ) {
        boolean tryAgain = true;
        Scanner keyboard = new Scanner(System.in);
        while (tryAgain)
        {
            System.out.println("Enter month, day, and year.");
              System.out.println("Do not use a comma.");
            String monthInput = keyboard.next( );
            int dayInput = keyboard.nextInt( );
            int yearInput = keyboard.nextInt( );
            if (dateOK(monthInput, dayInput, yearInput) )
            {
                setDate(monthInput, dayInput, yearInput);
                tryAgain = false;
            }
            else
                System.out.println("Illegal date. Reenter input.");
         }
    }
    /**
     * @param monthInt month as integer(1..12)
     * @param dayInt day of  month as integer
     * @param yearInt a four digit number
     * @return true if integer representation of date is OK 
     */
    private boolean dateOK(int monthInt, int dayInt, int yearInt) {
        return ( (monthInt >= 1) && (monthInt <= 12) &&
                 (dayInt >= 1) && (dayInt <= 31) &&
                 (yearInt >= 1000) && (yearInt <= 9999) );
    }
    /**
     * @param monthString month as string (January..December)
     * @param dayInt day of  month as integer
     * @param yearInt a four digit number
     * @return true if date components are OK 
     */
    private boolean dateOK(String monthString, int dayInt, int yearInt) {
        return ( monthOK(monthString) &&
                 (dayInt >= 1) && (dayInt <= 31) &&
                 (yearInt >= 1000) && (yearInt <= 9999) );
    }
    /**
     * Check wher a valid month name was given as a parameter
     * @param month name of a month
     * @return true if month is  a valid month name (January..December)
     */
    private boolean monthOK(String month) {
        return (month.equals("January") || month.equals("February") ||
                month.equals("March") || month.equals("April") ||
                month.equals("May") || month.equals("June") ||
                month.equals("July") || month.equals("August") ||
                month.equals("September") || month.equals("October") ||
                month.equals("November") || month.equals("December") );
    }
    /**
     * Returns month name for an integer month (1..12) 
     *@param monthNumber month as a number (1..12)
     * @return  name of  month
     */
    private String monthString(int monthNumber) {
        switch (monthNumber)
        {
        case 1:
            return "January";
        case 2:
            return "February";
        case 3:
            return "March";
        case 4:
            return "April";
        case 5:
            return "May";
        case 6:
            return "June";
        case 7:
            return "July";
        case 8:
            return "August";
        case 9:
            return "September";
        case 10:
            return "October";
        case 11:
            return "November";
        case 12:
            return "December";
        default:
            System.out.println("Fatal Error getting month name");
            System.exit(0);
            return "Error"; //to keep  compiler happy
        }
    }
}
