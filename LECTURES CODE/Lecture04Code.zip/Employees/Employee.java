public class Employee
{
    private String name; // name of  employee
    private Date hireDate; // date when he/she was hired
    /**
     * Parameterless constructor for Employee
     * creates an Emplyee instace with name "no name" hired on 01.01.1000 :-)
     */
    public Employee( ) {
         name = "No name";
         hireDate = new Date("January", 1, 1000); //Just a placeholder.
    }

    /**
    *Creates a new Employee object with  given name and hire date
    *@param Name name of  Employee object
    * @param Date date of hire
    */
    public Employee(String name, Date date) {
        if (name == null || date == null)
        {
             System.out.println("Fatal Error creating employee.");
             System.exit(0);
        }
        this.name = name;
        hireDate = new Date(date);
    }
    /**
     * Creates an Employee object from anor Employee object
     * @param originalObject an Employee object
     */
    public Employee(Employee originalObject) {
         name = originalObject.name;
         hireDate = new Date(originalObject.hireDate);
    }
    /**
     * @return  name of this Employee
     */
    public String getName( ) {
        return name;
    }
    /**
     * @return  hire date of this Employee
     */
    public Date getHireDate( ) {
        return new Date(hireDate);
    }
    /**
    * Sets  name of this Employee object
    * @param newName name to set for this Employee
    */
    public void setName(String newName) {
        if (newName == null)
        {
             System.out.println("Fatal Error setting employee name.");
             System.exit(0);
        }
       else
            name = newName;
    }
    /**
    * Sets  hire date of this Employee object
    * @param newDate date of hire to set
    */
    public void setHireDate(Date newDate) {
        if (newDate == null)
        {
             System.out.println("Fatal Error setting employee hire date.");
             System.exit(0);
        }
        else
            hireDate = new Date(newDate);
    }
    /**
     * @return a readable representation of  Employee object
     */
    public String toString( ) {
        return (name + " " + hireDate.toString( ));
    }

    /**
     *Checks if contents of this Employee and  or have identical contents
     *@param orEmployee Employee object to compare with
     *@return true if  this instance and orEmployee have identical contents
     */
    public boolean equals(Employee originalEmployee)
    {
        return (name.equals(originalEmployee.name)
                       && hireDate.equals(originalEmployee.hireDate));
    }
}

