public class SalariedEmployee extends Employee
{
    private double salary; //annual wage
    /**
     * Parameterless constructor for SalariedEmployee objects
     * invokes superclass constructor for intilalizing name and hire date to ir default values
     * @see Employee.java#Employee()
    */
    public SalariedEmployee( )  {
        super( );
        salary = 0;
    }
    /**
     * Constructor for SalariedEmployee objects
     * @param Name name of employee
     * @param Date date of hire
     * @param Salary annual salary in US$
    */
    public SalariedEmployee(String name, Date date, double salary) {
         super(name, date);
         if (salary >= 0)
             salary = this.salary;
         else
         {
             System.out.println("Fatal Error: Negative salary.");
             System.exit(0);
         }
    }
    /**
     * Creates a SalariedEmployee object from anor SalariedEmployee object
     * @param originalObject a SalariedEmployee object
     */
    public SalariedEmployee(SalariedEmployee originalObject ) {
         super(originalObject);
         salary = originalObject.salary;
    }
    /**
     * @return  annual salary 
     */
    public double getSalary( ) {
        return salary;
    }
    /**
     Returns  pay for  month.
    */
    public double getPay( ) {
        return salary/12;
    }
    /**
     Precondition: newSalary is nonnegative.
    */
    public void setSalary(double newSalary) {
         if (newSalary >= 0)
             salary = newSalary;
         else
         {
             System.out.println("Fatal Error: Negative salary.");
             System.exit(0);
         }
    }
    /**
     * @return a readable representation of  SalariedEmployee object
     */
    public String toString( ) {
        return (getName( ) + " " + getHireDate( ).toString( ) 
                                + "\n$" + salary + " per year");
    }
    /**
     * @param SalariedEmployee object to compare with
     * @return true if this SalariedEmployee has identical atributes
     * with or
     */
    public boolean equals(SalariedEmployee or) {
        return (getName( ).equals(or.getName( )) 
                && getHireDate( ).equals(or.getHireDate( ))
                && salary == or.salary);
    }
}
