// Author: David Riley
// Date: July, 2002

import javax.swing.*;
public class Driver  { 
     public static void main(String[] args)   {
        Driver driver = new Driver();
     }
    public Driver()   {
        Fraction f1, f2, f3;
        f1 = new Fraction(1,3);
        f2 = new Fraction(3,5);
        System.out.println("1/3 + 3/5 is " + f1.sum(f2));
        System.out.println("1/3 * 3/5 is " + f1.product(f2));
        f2.invert();
        System.out.println("1/3 / 3/5 is " + f1.product(f2));
        f3 = new Fraction(-15,30);
        System.out.println("1/3 + -15/30 is " + f1.sum(f3));
        System.out.println("1/3 * -15/30 is " + f1.product(f3));
    }
}