// Author: David Riley
// Date: July, 2002

/* invariant  (For every Fraction object)
        denominator > 0
        and gcd(numerator, denominator) == 1  (i.e., this fraction is normalized)  */
public class Fraction {
   private int numerator;
   private int denominator;

   /*	pre:	d != 0  (throws FractionException)
        post:	real_valueOf(this) == n / d  */
   public Fraction(int n, int d) {
        if (d == 0)  throw new FractionException("denominator cannot be zero");
        if (d < 0)   {
            numerator = -n;
            denominator = -d;
        } else {
            numerator = n;
            denominator = d;
        }
        simplify();
   }
   
   /*	post:	result == numerator  */
   public int numer()   {
        return numerator;
   }
   
   /*	post:	result == denominator  */
   public int denom()   {
        return denominator;
   }

    /* 	pre:	numerator != 0  (throws FractionException)
        modifies:	numerator, denominator
        post:	real_value_of(this) == 1 / (real_value_of(this@pre))  */
    public  void  invert()  {
        if (numerator == 0)  throw new FractionException("can't invert fraction with zero numerator");
        int temp = numerator;
        numerator = denominator;
        denominator = temp;		
        if (denominator < 0)   {
            denominator = -denominator;
            numerator = -numerator;
        }
    }
    
    /* 	modifies:	numerator
        post:	real_value_of(this) == -real_value_of(this@pre)  */
    public  void  negate()   {
        numerator = -numerator;
    }
	
    /* 	pre:	f != null (throws FractionException)
        modifies:	numerator, denominator
        post:	real_value_of(result) == real_value_of(this) + real_value_of(f) */
    public Fraction sum(Fraction f) {
        if (f == null)  throw new FractionException("null-valued argument");
        Fraction result;
        int newNumerator = numerator*f.denom() + f.numer()*denominator;
        int newDenominator = denominator * f.denom();
        if (newDenominator >= 0)   {
            result = new Fraction(newNumerator, newDenominator);
        } else {
            result = new Fraction(-newNumerator, -newDenominator);
        }
        result.simplify();
        return result;
    }
    
    /* 	pre:	f != null (throws FractionException)
        modifies:	numerator, denominator
        post:	real_value_of(result) == real_value_of(this) * real_value_of(f) */
    public Fraction product(Fraction f) {
        if (f == null)  throw new FractionException("null-valued argument");
        Fraction result;
        result = new Fraction(numerator*f.numer(), denominator*f.denom());
        result.simplify();
        return result;
    }
  
	/*	post:	result == numerator + "/" + denominator  */
    public String toString()   {
        return numerator + "/" + denominator;
    }
    
    /* post:	real_value_of(this) = real_value_of(this@pre)
                and gcd(numerator,denominator) == 1 */
    private void simplify()   {
        int div = 2;
        while ( div <= min(Math.abs(numerator), denominator) )   {
            if ( (numerator % div == 0)  &&  (denominator % div == 0) )   {
                numerator = numerator / div;
                denominator = denominator / div;
            } else {
                div++;
            }
        }
    }
    
    /* post:	a < b  implies  result == a
                and  a >=b  implies  result == b */
    private int min(int a, int b)   {
        if (a < b)   {
            return a;
        } else {
            return b;
        }
    }
    
}


/*	Specification Functions
            real_value_of(Fraction f)      [a Real-valued function]
                DEFINITION
                    real_value_of(f) == f.numerator / f.denominator
                INFORMALLY
                    real_value_of(f) is the numeric value from dividing the numerator of f 
                                        by its denominator.

            gcd(int a, int b) [an Integer-valued function]
                DEFINITION
                    gcd(a, b) > 0
                    and  a % gcd(a, b) == 0
                    and  b % gcd(a, b) == 0
                    and  forAll (j : Integer  and  j > gcd(a, b)   |  a % j != 0  or  b % j != 0)
                INFORMALLY
                    gcd(a, b) is the greatest common divisor of a and b */
