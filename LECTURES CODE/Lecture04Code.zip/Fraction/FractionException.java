// Author: David Riley
// Date: July, 2002

/* This type of excepion is associated with methods applied to the Fraction class. */
public class FractionException extends RuntimeException {

   public FractionException() {
        super();
   }

   public FractionException(String s) {
        super(s);
   }
}