
/**
 * Write a description of class ClassA here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ClassA {
    public void methodOne(int i) {
    }
    public void methodTwo(int i) {
    }
    public static void methodThree(int i) {
    }
    public static void methodFour(int i) {
    }
}

