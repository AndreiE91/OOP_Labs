
/**
 * Write a description of class ClassB here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ClassB extends ClassA {
    //public static void methodOne(int i) {
    //}
    public void methodTwo(int i) {
    }
    //public void methodThree(int i) {
    //}
    public static void methodFour(int i) {
    }
}