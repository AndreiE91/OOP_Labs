public class AncestorsDemo  
{
    public static void main(String[] args) 
    {
        new AncestorsDemo();
    }

    /* *
     *  Creates a Child object and prints the names of all its ancestors classes
     *  from java.lang.Object through Child, one per line. 
     */
    public AncestorsDemo()  
    {
        System.out.println("-----------------------------");
        Child exampleObject = new Child();
        printAllAncestorClasses( exampleObject.getClass() );
        System.out.println("-----------------------------");
        Object o = new Parent();
        printAllAncestorClasses( o.getClass() );
    }   

    /* *
     *  Recursively prints all ancestprs of class c, one per line
     * @param c class for which to print ancestors
     */ 
    private void printAllAncestorClasses( Class c )  
    {
        if (c.getSuperclass() != null)
        {
            printAllAncestorClasses( c.getSuperclass() );
        }
        System.out.println(c.getName());
    }
}
