// Author: David Riley
// Date: July, 2002

public class Grandparent  {

    public Grandparent()   {
    }
}
