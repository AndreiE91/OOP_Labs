// Author: David Riley
// Date: July, 2002

public class Parent extends Grandparent  {

    public Parent()   {
    }
}
