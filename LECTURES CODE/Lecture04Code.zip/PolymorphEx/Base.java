public class Base {
   protected int theInt = 100;

   public void printTheInt() {
              System.out.println("b----------------------");
      System.out.println( "Base: " + theInt );
   }
}
