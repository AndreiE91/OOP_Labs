public class Doubler extends Base {
   public void printTheInt() {
      System.out.println("d----------------------");
   super.printTheInt();
      System.out.println( "Doubler:" + theInt*2 );
   }
}
