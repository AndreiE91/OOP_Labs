public class Squarer extends Tripler 
{
    public void printTheInt() 
    {
       System.out.println("s----------------------");
       super.printTheInt();
       System.out.println( "Squarer:" + theInt*theInt );
    }
}
