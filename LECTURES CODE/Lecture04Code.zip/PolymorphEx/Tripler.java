public class Tripler extends Base {
   public void printTheInt() {
       System.out.println("t----------------------");
       super.printTheInt();
      System.out.println( "Tripler: " + theInt*3 );
   }
}
