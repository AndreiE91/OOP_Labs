
/**
 * Write a description of class ReadOne here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ReadOne
{
    public static void main() throws java.io.IOException
    {
        byte[] b = new byte[2];
        int count = 1;
        do
        {
            System.out.println(count++ + " Type Enter ");
            System.in.read(b);
        }
        while (true);
    }
}
