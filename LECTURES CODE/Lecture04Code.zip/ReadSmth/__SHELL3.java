
public class __SHELL3 extends bluej.runtime.Shell {

public static void run() throws Throwable {

ReadOne.main();


}}