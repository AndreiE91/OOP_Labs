// Author: David Riley
// Date: July, 2002

public class Cube extends GeometricSolid 
{
    private double side;
    
    /*  post:   side == s */
    public Cube(double s) 
    {
        side = s;
    }
    
    /*  post:   result == 6 * side * side */
    public double area()   
    {
        return 6 * side * side;
    }
                    
    public double volume()
    {
        return side * side * side;
    }
    /*  post:   result == z.side == side */
    public boolean equals(Object z) 
    {
        return z instanceof Cube
                &&  side == ((Cube)z).side;
    }
        
    /*  post:   result == "Cube" concatenated to the cube's side length */
    public String toString()  
    {
        return "Cube (Side: " + side + ")";

    }

}
