// Author: David Riley
// Date: July, 2002

public class Cylinder extends GeometricSolid implements Cloneable 
{
    private double height;
    private double radius;
    
    /*  post:   height == h  and  radius == r */
    public Cylinder(double h, double r) 
    {
        height = h;
        radius = r;
    }
    
    /*  post:   result == 2 * Math.PI * height * radius + 2 * Math.PI * radius * radius */
    public double area()   
    {
        return 2 * Math.PI * height * radius + 2 * oneEndCap();
    }
    
    public double volume()
    {
        return oneEndCap() * height;
    }
    /*  post:   result == Math.PI * radius * radius */
    private double oneEndCap()   
    {
        return Math.PI * radius * radius;
    }
    
    /*  post:   result == "Cylinder with End Caps" concatenated to the cylinder's dimensions */
    public String toString()   
    {
        return "Cylinder with End Caps (Height: " + height + "   Radius: " + radius + ")";
    }
    
    /*  post:   result == z.height == height
                and  z.radius == radius */
    public boolean equals(Object z) 
    {
        return z instanceof Cylinder
                &&  height == ((Cylinder)z).height
                &&  radius == ((Cylinder)z).radius;
    }
}
