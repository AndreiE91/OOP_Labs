// Author: David Riley
// Date: July, 2002

import javax.swing.*;
public class Driver 
 { 
     public static void main(String[] args)  
     {
        Driver driver = new Driver();
    }
     
    public Driver()  
    {
        GeometricSolid[] solid = new GeometricSolid[3];
        solid[0] = new Cylinder(10, 10);
        solid[1] = new Sphere(10);
        solid[2] = new Cube(10);
        for (int j=0; j!= solid.length; j++)  
        {
            System.out.print( "Solid Type: " );
            System.out.println( solid[j] );
            System.out.println( "\tSurface Area: " + solid[j].area() + ". Volume: " + solid[j].volume() );
        }
        
        Cylinder myCylinder, yourCylinder;
        myCylinder = new Cylinder(10, 20);
        yourCylinder = new Cylinder(10, 20);
        System.out.print( myCylinder + " compared to " + yourCylinder + " ");
        if ( myCylinder.equals(yourCylinder) )  
        {
            System.out.println("Content Equality" );
        } 
        else 
        {
            System.out.println( "Content Inequality" );
        }
    }
}