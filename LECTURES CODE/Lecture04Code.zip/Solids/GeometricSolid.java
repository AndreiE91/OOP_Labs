/**
 * Abstract class declaring a single method: area()
 */
public abstract class GeometricSolid 
{
    public GeometricSolid() 
    {
    }
    
    /*  @return the total surface area for this solid */
    public abstract double area();  
    public abstract double volume();
}
