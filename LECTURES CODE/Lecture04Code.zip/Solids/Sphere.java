// Author: David Riley
// Date: July, 2002

public class Sphere extends GeometricSolid
{
    private double radius;
    
    /*  post:   radius == r */
    public Sphere(double r)
    {
        radius = r;
    }
    
    /*  post:   result == 4 * Math.PI * radius * radius */
    public double area()  
    {
        return 4 * Math.PI * radius * radius;
    }
    
    public double volume()
    {
        return 4.0 * radius * radius * radius * Math.PI / 3.0;
    }
    /*  post:   result == "Sphere" concatenated to the sphere's radius */
    public String toString()  
    {
        return "Sphere (Radius: " + radius + ")";
    }
            
    /*  post:   result == z.radius == radius */
    public boolean equals(Object z) 
    {
        return z instanceof Sphere
                &&  radius == ((Sphere)z).radius;
    }
}
