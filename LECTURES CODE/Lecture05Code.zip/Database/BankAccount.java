/** BankAccount models a bank account with an identification key */
public class BankAccount implements Record
{ 
    private int balance; // the account's balance
    private Key id; // the identification key
    /** Constructor Record initializes the account
    * @param initial amount - the starting account balance, a nonnegative.
    * @param id - the account's identification key */
    public BankAccount(int initialAmount, Key id)   
    { 
        balance = initialAmount;
        this.id = id;
    }
    /** deposit adds money to the account.
    * @param amount - the amount of money to be added, a nonnegative int */
    public void deposit(int amount)
    { 
        balance = balance + amount; 
    }
    /** getBalance reports the current account balance
    * @return the balance */
    public int getBalance() 
    { 
        return balance; 
    }
    /** getKey returns the account's key
    * @return the key */
    public Key getKey() 
    { 
        return id; 
    }
    /** toString gives a readable form of BankAccount 
     * includes the account id and balance */
    public String toString()
    {
        return "Account id:" + id.toString() + " balance:" + balance; 
    }
}
