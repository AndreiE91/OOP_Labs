
/**
 * Write a description of class Cat here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cat implements Record
{
	// instance variables - replace the example below with your own
	private String name;
	private Key k;

	/**
	 * Constructor for objects of class Cat
	 */
	public Cat(String n, Key k)
	{
		// initialise instance variables
		name = n;
		this.k =k;
	}

 /** getKey returns the cat's key :-)
    * @return the key */
    public Key getKey() 
    { 
        return k; 
    }
    public String toString()
    {
        return "I'm a cat. My name is: " + name + ". My id is:" + k.toString();
    }
}
