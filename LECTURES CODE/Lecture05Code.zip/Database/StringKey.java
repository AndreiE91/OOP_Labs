
/**
 * Write a description of class StringKey here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StringKey implements Key
{
    // instance variables - replace the example below with your own
    private String s;

    /**
     * Constructor for objects of class StringKey
     */
    public StringKey(String key)
    {
        // initialise instance variables
        s = key;
    }

    public boolean equals(Key c)
    { 
        return s.equals(((StringKey)c).s ); 
    }
    public String toString()
    {
        return s;
    }

}
