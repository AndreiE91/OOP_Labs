
/**
 * Write a description of class TestDatabase here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TestDatabase
{
    public static void main(String[] args)
    {
        Database db = new Database(5); 
        db.insert(new BankAccount(1000, new IntegerKey(23)));
        db.insert(new BankAccount(800, new IntegerKey(11)));
        db.insert(new BankAccount(300, new IntegerKey(7)));
        db.list();
        db.delete(new IntegerKey(11));
        db.list();
        // Cat unrelated part
        Cat myCat = new Cat("Helen", new IntegerKey(17));
        db.insert(myCat);
        db.list();
        Database dbs = new Database(5); 
        dbs.insert(new BankAccount(1000, new StringKey("s23")));
        dbs.insert(new BankAccount(800, new StringKey("k11")));
        dbs.insert(new BankAccount(300, new StringKey("z7")));
        dbs.list();
        dbs.delete(new StringKey("s23"));
        dbs.list();
        // Cat unrelated part
        Cat myCats = new Cat("Helen", new StringKey("y17"));
        dbs.insert(myCats);
        dbs.list();
        
    }
}
