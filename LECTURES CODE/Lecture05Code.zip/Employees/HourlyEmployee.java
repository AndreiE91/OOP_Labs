public class HourlyEmployee extends Employee 
{
    private double wageRate; // amount of pay per hour
    private double hours; // hours worked in a month
    /**
     * Parameterless constructor for HourlyEmployee objects
     * invokes superclass constructor for initializing name and hire date to ir default values
     * wage rate and hours worked set to zero
     * @see Employee.java#Employee()
    */
    public HourlyEmployee( ) {
        super( );
        wageRate = 0;
        hours = 0;
    }
    /**
     *Constructor for HourlyEmployee objects.
     * The HourlyEmployee will have name, hire date, wage rate and hours worked as provided
     *@param Name name of  employee
     *@param Date date of hire
     *@param WageRate hourly wage
     *@param Hours hours worked
    */
    public HourlyEmployee(String name, Date date,
                       double wageRate, double hours) {
         super(name, date);
         if ((wageRate >= 0) && (hours >= 0))
         {
             this.wageRate = wageRate;
             this.hours = hours;
         }
         else
         {
             System.out.println(
                       "Fatal Error: creating an illegal hourly employee.");
             System.exit(0);
         }
    }
   /**
     * Creates a HourlyEmployee object from anor HourlyEmployee object
     * @param originalObject a HourlyEmployee object
     */
    public HourlyEmployee(HourlyEmployee originalObject) {
         super(originalObject);
         wageRate = originalObject.wageRate;
         hours = originalObject.hours;
    }
   /**
   * @return  hourly wage
   */
    public double getRate( ) {
        return wageRate;
    }
    /**
     * @return hours worked 
     */
    public double getHours( ) {
        return hours;
    }
    /**
     Returns  pay for  hours worked
    */
    public double getPay( ) {
        return wageRate * hours;
    }
    /**
    * Sets  number of hours worked
    * @param hoursWorked a strictly positive amount of hours
    */
    public void setHours(double hoursWorked) {
         if (hoursWorked >= 0)
             hours = hoursWorked;
         else
         {
             System.out.println("Fatal Error: Negative hours worked.");
             System.exit(0);
         }
     }
    /**
     Precondition: newWageRate is nonnegative.
    */
    public void setRate(double newWageRate) {
         if (newWageRate >= 0)
             wageRate = newWageRate;
         else
         {
             System.out.println("Fatal Error: Negative wage rate.");
             System.exit(0);
         }
    }
    /**
     * @return a readable representation of  HourlyEmployee object
     */
    public String toString( )  {
        return (getName( ) + " " + getHireDate( ).toString( ) 
                + "\n$" + wageRate + " per hour for " + hours + " hours");
    }
    /**
     * @param HourlyEmployee object to compare with
     * @return true if this HourlyEmployee has identical atributes
     * with or
     */
    public boolean equals(HourlyEmployee or) {
       return (getName( ).equals(or.getName( )) 
                && getHireDate( ).equals(or.getHireDate( ))
                && wageRate == or.wageRate
                && hours == or.hours);
    }
}
