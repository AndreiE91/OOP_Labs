/**
 * Write a description of class OtherPaintable here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class OtherPaintable implements Paintable {
	int finish;
	int x;
	int y;
	int color;

  public OtherPaintable(int x, int y, int Color, int finish)
  {
  	this.finish=finish;
  	this.x=x;
  	this.y=y;
  	this.color=Color;
  } 
  
	public void setFinish(int finish)
	{
		this.finish = finish;
	}

	public int getFinish()
	{
		return finish;
	}

	public void setColor(int color)
	{
		this.color = color;
	}

	public int getColor()
	{
		return color;
	}
}