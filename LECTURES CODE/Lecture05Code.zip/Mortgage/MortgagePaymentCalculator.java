/** MortgagePaymentCalculator makes mortgage payments */
public class MortgagePaymentCalculator
{
	private BankAccountSpecification bankAccount; // holds the address of

	// an object that implements the BankAccountSpecification
	/** Constructor MortgagePaymentCalculator initializes the calculator.
	 * @param account - the address of the bankAccount from which we
	 * make deposits and withdrawals */
	public MortgagePaymentCalculator(BankAccountSpecification account)
	{
		bankAccount = account;
	}

	/** makeMortgagePayment makes a mortgage payment from the bankAccount.
	 * @param amount - the amount of the mortgage payment */
	public void makeMortgagePayment(int amount)
	{
		boolean ok = bankAccount.withdraw(amount);
		if (ok)
		{
			System.out.println("Payment made: " + amount);
		}
		else
		{
			System.out
					.println("Could not make mortgage payment. Check your balance");
		}
	}

}