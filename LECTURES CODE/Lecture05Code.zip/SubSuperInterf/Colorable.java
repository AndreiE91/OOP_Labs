public interface Colorable
{
	void setColor(int color);

	int getColor();
}