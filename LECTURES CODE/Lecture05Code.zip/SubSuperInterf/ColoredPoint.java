class ColoredPoint extends Point implements Colorable
{
	int color;

	public void setColor(int color)
	{
		this.color = color;
	}

	public int getColor()
	{
		return color;
	}
}