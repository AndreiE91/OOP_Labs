class Point
{
	int x, y;
}