public class DoubleMistake {
    public static void main(String[] args)  {
        int num = 5, denom = 0, result;
        int[] arr = {7, 21, 31};
        try
        {
            result = arr[num];
            result = num / denom;
        }
        catch (ArithmeticException ex) 	{
            System.out.println("Arithmetic error");
        }
        catch (IndexOutOfBoundsException ex)  {
            System.out.println("Index error");
        }
    }
}