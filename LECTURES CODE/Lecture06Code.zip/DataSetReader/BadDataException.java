/**
   This class reports bad input data.
*/
public class BadDataException extends Exception
{
   public BadDataException() 
   {
      super("Unknown Bad Data");
   }
   public BadDataException(String message)
   {
      super(message);
   }
}
