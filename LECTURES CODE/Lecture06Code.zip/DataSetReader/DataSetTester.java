import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.NoSuchElementException;

public class DataSetTester 
{
   public static void main(String[] args)
   {
      Scanner in = new Scanner(System.in);
      DataSetReader reader = new DataSetReader();
      
      boolean done = false;
      while (!done) 
      {
         try 
         {
            System.out.println("Please enter the file name (end program with ^Z): ");
            String filename = in.next();
            
            double[] data = reader.readFile(filename);
            double sum = 0;
            for (double d : data) sum = sum + d; 
            System.out.println("The sum is " + sum);
            done = true;
         }
         catch (NegativeArraySizeException ex)
         {
             System.out.println("Negative number of values");
         }

         catch (NoSuchElementException ex)
         {   // thrown when user enters ^Z
             System.out.println("Program ended");
             System.exit(0);
         }
         catch (FileNotFoundException ex)
         {  // thrown when file name given by user is missing
            System.out.println("File not found.");
         }
         catch (BadDataException ex)
         {  // thrown for incorrectly formatted or too much/little data for reading
            System.out.println("Bad data: " + ex.getMessage());
         }
         catch (IOException ex)
         {
            ex.printStackTrace();
         }
      }
   }
}
