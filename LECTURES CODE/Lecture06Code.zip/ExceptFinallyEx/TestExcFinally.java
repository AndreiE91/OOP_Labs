import java.io.*;
import java.util.*;
/**
 * Demo for exceptions.
 */
public class TestExcFinally
{
    private String filename; // name of file to read from
    private int[] intArray = new int[10];
    /**
     * Constructor for class TestExcFinally
     */
    public TestExcFinally()
    {
        filename = "MissingFile";
        System.out.println("\n----------------------------\nObject of class TestExcFinally constructed");
    }
    // reads integers into array intArray
    public void read() throws FileNotFoundException, IOException
    {
        FileReader reader = new FileReader(filename); 
        System.out.println("reader constructed");
        try 
        { 
            Scanner in = new Scanner(reader); 
            System.out.println("Scanner object constructed");
            int i = 0;
            System.out.println("\treading element: ");
            while ( i < intArray.length )
            {
                intArray[ i ] = in.nextInt();
                System.out.print(" " + i++);
                
            }
        } 
        finally 
        {   // will not get executed if FileNotFoundException (thrown outside try)
            reader.close();
            System.out.println("\nFinally clause executed");
        }
    }
    public static void main(String[] args)
    {
        TestExcFinally t = new TestExcFinally();
        try
        {
            t.read();
        }
        catch ( FileNotFoundException e )
        {
            System.out.println("\n---FileNotFoundException---\n" + e.getMessage());
        }
        catch ( IOException e )
        {
            System.out.println("\n---IOException---\n" + e.getMessage());
        }
        catch ( InputMismatchException e )
        {
            System.out.println("\n---InputMismatchException---\n");
        }            
        catch ( NoSuchElementException e)
        {
            System.out.println("\n--Not enough data--\n");
        }
    }
            
}
