import java.util.Scanner;

public class InputMismatchExceptionDemo
{
	public static void main(String[] args)
	{
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Enter one integer:");
		int inputNumber = keyboard.nextInt();
		System.out.println("The square of  " + inputNumber + " is "
				+ inputNumber * inputNumber);
	}
}
