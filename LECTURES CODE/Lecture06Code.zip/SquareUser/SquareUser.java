import java.lang.* ;
import java.io.* ;

public class SquareUser 
{

  public static void main ( String[] a ) throws IOException
  {
    BufferedReader stdin = 
        new BufferedReader ( new InputStreamReader( System.in ) );
 
    String  inData = null;
    int     num = 0;
    boolean goodData = false;

    while ( !goodData )
    {
      System.out.println("Enter an integer:");
      inData = stdin.readLine();

      try
      {
        num      = Integer.parseInt( inData );
        goodData = true;
      }

      catch (NumberFormatException ex )
      {
        System.out.println("You entered bad data." );
        System.out.println("Please try again.\n" );
      }

    }

    System.out.println("The square of " + inData + " is " + (num*num) );

  }
}
