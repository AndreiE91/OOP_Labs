import java.io.Serializable;
/**
 * Write a description of class Person here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Person  implements Serializable
{
    // instance variables - replace the example below with your own
    private String firstNames[];
    private String lastName;

    /**
     * Constructor for objects of class Person
     */
    public Person(String fName, String lName)
    {
        firstNames = new String[1];
        firstNames[0] = fName;
        lastName = lName;
    }
    public String toString()
    {
        String s = lastName;
        for (int i=0; i < firstNames.length; i++)
           s += " " + firstNames[i];
        return s;
    }
}
