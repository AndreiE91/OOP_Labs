import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;
public class AfineTransf extends JPanel 
{
   public void paintComponent ( Graphics g ) 
   {
      super.paintComponent(g);
      // Cast the graphics object to Graph2D
      Graphics2D g2 = (Graphics2D) g;
      // Get the affine transform
      AffineTransform at = new AffineTransform();
      Color colorArray[] = new Color[] {
        Color.blue, Color.cyan, Color.magenta,
        Color.black, Color.blue, Color.cyan,
        Color.magenta, Color.black };
      g2.setFont(new Font("SansSerif",Font.BOLD,16));
      for ( int i = 0;  i < 8; i++)
      {
         at.rotate(Math.PI/4, 180, 180);
         g2.setTransform(at);
         g2.setColor(colorArray[i]);
         //Rectangle2D.Float r=new Rectangle2D.Float(250f, 250f, 10f, 20f);
         //g2.fill(r);
         g2.drawString("Java Graphics!", 200, 200);
      }
      super.setBackground( Color.white );
    }
    public static void main(String s[]) 
    {
      // Create a Window Listener to handle "close" events
      WindowListener l = new WindowAdapter()
      {
        public void windowClosing(WindowEvent e) 
        { 
            e.getWindow().dispose();
            System.exit(0); 
        }
      };
      // Create a blank yellow JPanel to use as canvas
      AfineTransf af = new AfineTransf();
      // Create a frame and place the canvas in the center
      // of the frame.
      JFrame f = new JFrame("AfineTransf...");
      f.addWindowListener(l);
      f.add(af, BorderLayout.CENTER);
      f.pack();
      
      af.paintComponent(f.getGraphics());
      f.setSize(370,370);
      f.setVisible(true);
    }
}
