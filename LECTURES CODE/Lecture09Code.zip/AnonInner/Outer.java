import java.awt.event.*;
class Outer extends java.awt.Frame
{
    public Outer()
    {
        java.awt.Button button = new java.awt.Button("Click on me");
        this.add(button);
        button.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                System.out.println("You clicked");
            }
        });
    }
    public void showOuter()
    {
        this.setVisible(true);
    }
}