import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;
public class DisplayFonts extends JPanel {
   public void paintComponent ( Graphics g ) {
        super.paintComponent(g);
        // Cast the graphics object to Graph2D
        Graphics2D g2 = (Graphics2D) g;
        // Define some fonts
        Font f1 = new Font("Serif",Font.PLAIN,12);
        Font f2 = new Font("SansSerif",Font.ITALIC,16);
        Font f3 = new Font("Monospaced",Font.BOLD,14);
        Font f4 = new Font("Serif",Font.BOLD+Font.ITALIC,20);
        // Display fonts
        g2.setColor( Color.black );
        g2.setFont(f1);
        g2.drawString("12-point plain Serif",20,20);
         g2.setColor( Color.cyan );
        g2.setFont(f2);
        g2.drawString("16-point italic SansSerif",250,20);
        g2.setFont(f3);
         g2.setColor( Color.green );
        g2.drawString("14-point bold Monospaced",20,40);
        g2.setFont(f4);
        g2.drawString("20-point bold italic Serif",250,40);
        super.setBackground( Color.white );
    }
    public static void main(String s[]) 
    {
      // Create a Window Listener to handle "close" events
      MyWindowListener l = new MyWindowListener();
      // Create a blank yellow JPanel to use as canvas
      DisplayFonts df = new DisplayFonts();
      // Create a frame and place the canvas in the center
      // of the frame.
      JFrame f = new JFrame("DisplayFonts...");
      f.addWindowListener(l);
      f.add(df, BorderLayout.CENTER);
      f.pack();
      
      df.paintComponent(f.getGraphics());
      f.setSize(500,80);
      f.setVisible(true);
    }
}
