import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.util.Locale;
/**
 * An action listener that prints a message.
*/
public class ClickListener implements ActionListener
{
   public void actionPerformed(ActionEvent event)
   {
       java.sql.Time t = new java.sql.Time(event.getWhen()); 
       DateFormat df = DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.FULL);

      System.out.println("You clicked me." + df.format(t));
   }            
} 

