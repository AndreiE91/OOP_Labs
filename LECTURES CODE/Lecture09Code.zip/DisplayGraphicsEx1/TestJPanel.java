import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class TestJPanel {

   public static void main(String s[]) {

      // Create a Window Listener to handle "close" events
      MyWindowListener l = new MyWindowListener();

      // Create a blank yellow JPanel to use as canvas
      JPanel c = new JPanel();
      c.setBackground( Color.yellow );

      // Create a frame and place the canvas in the center
      // of the frame.
      JFrame f = new JFrame("Test JPanel ...");
      f.addWindowListener(l);
      f.add(c, BorderLayout.CENTER);
      f.pack();
      f.setSize(400,400);
      f.setVisible(true);
   }
}