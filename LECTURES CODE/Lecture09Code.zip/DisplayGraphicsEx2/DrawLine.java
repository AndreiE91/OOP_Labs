import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;
public class DrawLine extends JPanel {
   public void paintComponent ( Graphics g ) {
      // Cast the graphics object to Graph2D
      Graphics2D g2 = (Graphics2D) g;
      // Set background color
      Dimension size = getSize();
      g2.setColor( Color.white );
      g2.fill(new Rectangle2D.Double(0,0,
              size.width,size.height));
      // Draw line
      g.setColor( Color.black );
      Line2D line = new Line2D.Double (10., 10., 360., 360.);
      g2.draw(line);
    }
    public static void main(String s[]) 
    {
      // Create a Window Listener to handle "close" events
      MyWindowListener l = new MyWindowListener();
      // Create a blank yellow JPanel to use as canvas
      DrawLine dl = new DrawLine();
      // Create a frame and place the canvas in the center
      // of the frame.
      JFrame f = new JFrame("Test DrawLine ...");
      f.addWindowListener(l);
      f.add(dl, BorderLayout.CENTER);
      f.pack();
      dl.paintComponent(f.getGraphics());
      f.setSize(390,390);
      f.setVisible(true);
    }
}
