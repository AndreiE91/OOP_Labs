import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;
public class DrawLines extends JPanel {
   public void paintComponent ( Graphics g ) {
      BasicStroke bs;                   // Ref to BasicStroke
      Line2D line;                      // Ref to line
      float[] solid = {12.0f,0.0f};     // Solid line style
      float[] dashed = {12.0f,20.0f, 1.0f, 8.0f};   // Dashed line style
      // Cast the graphics object to Graph2D
      Graphics2D g2 = (Graphics2D) g;

      // Set the Color and BasicStroke
      g2.setColor(Color.red);
      bs = new BasicStroke( 1.0f, BasicStroke.CAP_ROUND,
                            BasicStroke.JOIN_MITER, 1.0f,
                            solid, 0.0f );
      g2.setStroke(bs);
      // Draw line
      line = new Line2D.Double (10., 10., 360., 360.);
      g2.draw(line);
      // Set the Color and BasicStroke
      g2.setColor(Color.blue);
      bs = new BasicStroke( 8.0f, BasicStroke.CAP_ROUND,
                            BasicStroke.JOIN_MITER, 1.0f,
                            dashed, 0.0f );
      g2.setStroke(bs);
      // Draw line
      line = new Line2D.Double (10., 300., 360., 10.);
      g2.draw(line);
   }

    public static void main(String s[]) 
    {
      // Create a Window Listener to handle "close" events
      MyWindowListener l = new MyWindowListener();
      // Create a blank yellow JPanel to use as canvas
      DrawLines dl = new DrawLines();
      // Create a frame and place the canvas in the center
      // of the frame.
      JFrame f = new JFrame("Test DrawLines ...");
      f.addWindowListener(l);
      f.add(dl, BorderLayout.CENTER);
      f.pack();
      dl.paintComponent(f.getGraphics());
      f.setSize(390,390);
      f.setVisible(true);
    }
}
