import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;
public class DrawRectangle extends JPanel {

   // This method draws a rectangle.
   public void paintComponent ( Graphics g ) {

      BasicStroke bs;                   // Ref to BasicStroke
      Rectangle2D rect;                 // Ref to rectangle
      float[] solid = {12.0f,0.0f};     // Solid line style

      // Cast the graphics object to Graph2D
      Graphics2D g2 = (Graphics2D) g;

      // Set rendering hints to improve display quality
      g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                          RenderingHints.VALUE_ANTIALIAS_ON);

      // Set background color
      Dimension size = getSize();
      g2.setColor( Color.white );
      g2.fill(new Rectangle2D.Double(0,0,size.width,size.height));

      // Set the basic stroke
      bs = new BasicStroke( 3.0f, BasicStroke.CAP_SQUARE,
                            BasicStroke.JOIN_MITER, 1.0f,
                            solid, 0.0f );
      g2.setStroke(bs);

      // Define rectangle
      rect = new Rectangle2D.Double (30., 40., 200., 150.);
      g2.setColor(Color.yellow);
      g2.fill(rect);
      g2.setColor(Color.black);
      g2.draw(rect);
   }

   public static void main(String s[]) {

      // Create a Window Listener to handle "close" events
      MyWindowListener l = new MyWindowListener();

      // Create a DrawRect object
      DrawRectangle c = new DrawRectangle();

      // Create a frame and place the object in the center
      // of the frame.
      JFrame f = new JFrame("DrawRect ...");
      f.addWindowListener(l);
      f.getContentPane().add(c, BorderLayout.CENTER);
      f.pack();
      f.setSize(400,400);
      f.setVisible(true);
   }
}
