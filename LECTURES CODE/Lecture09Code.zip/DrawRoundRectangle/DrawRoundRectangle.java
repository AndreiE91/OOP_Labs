import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;
public class DrawRoundRectangle extends JPanel {

    // This method draws a rounded rectangle.
   public void paintComponent ( Graphics g ) {

      BasicStroke bs;                   // Ref to BasicStroke
      RoundRectangle2D rect;            // Ref to rectangle
      float[] dashed = {12.0f,12.0f};   // Dashed line style

      // Cast the graphics object to Graph2D
      Graphics2D g2 = (Graphics2D) g;

      // Set rendering hints to improve display quality
      g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                          RenderingHints.VALUE_ANTIALIAS_ON);

      // Set background color
      Dimension size = getSize();
      g2.setColor( Color.white );
      g2.fill(new Rectangle2D.Double(0,0,size.width,size.height));

      // Set the basic stroke
      bs = new BasicStroke( 3.0f, BasicStroke.CAP_SQUARE,
                            BasicStroke.JOIN_MITER, 1.0f,
                            dashed, 0.0f );
      g2.setStroke(bs);

      // Define rounded rectangle
      rect = new RoundRectangle2D.Double
                  (30., 40., 200., 150., 40., 40.);
      g2.setColor(Color.pink);
      g2.fill(rect);
      g2.setColor(Color.black);
      g2.draw(rect);
   }

   public static void main(String s[]) {

      // Create a Window Listener to handle "close" events
      MyWindowListener l = new MyWindowListener();

      // Create a DrawRoundRect object
      DrawRoundRectangle c = new DrawRoundRectangle();

      // Create a frame and place the object in the center
      // of the frame.
      JFrame f = new JFrame("DrawRoundRectangle");
      f.addWindowListener(l);
      f.getContentPane().add(c, BorderLayout.CENTER);
      f.pack();
      f.setSize(400,400);
      f.setVisible(true);
   }
}
