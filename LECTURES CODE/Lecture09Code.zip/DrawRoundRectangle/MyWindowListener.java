import java.awt.event.*;
public class MyWindowListener extends WindowAdapter {

   // This method implements a simple listener that detects
   // the "window closing event" and stops the program.
   public void windowClosing(WindowEvent e) {
      System.exit(0);
   };
}
