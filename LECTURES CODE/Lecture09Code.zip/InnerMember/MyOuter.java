public class MyOuter 
{
    private float variable = 0;
    public void doSomething() 
    {
        System.out.println("MyOuter doSomething");
    }
    public void testInnerFunction()
    {
       MyInner myIn = new MyInner();
       myIn.function();
    }
    private class MyInner  
    {
        public void doSomething() 
        {   
            System.out.println("MyInner doSomething");
        }
        public void function() 
        {
            //To call a function with the same name from the enclosing class
            MyOuter.this.doSomething();
        }
    }
 }