interface MyInterface {
    public String getInfo();
}
