class MyOuter 
{
    MyInterface current_object;
    public void setInterface(String info)   
    {
        class MyInner implements MyInterface   
        {
            private String info;
            public MyInner(String inf) {info=inf;}
            public String getInfo() {return info;}
        }
        current_object = new MyInner(info);
    }
}
