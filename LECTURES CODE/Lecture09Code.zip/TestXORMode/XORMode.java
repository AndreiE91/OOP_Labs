import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;
public class XORMode extends JPanel 
{
   public void paintComponent ( Graphics g ) 
   {
      super.paintComponent(g);
      // Cast the graphics object to Graph2D
      Graphics2D g2 = (Graphics2D) g;
	    // Two ellipses plotted them in normal mode                
      Ellipse2D ell1 = new Ellipse2D.Double (30., 30., 150., 80.);        
      Ellipse2D ell2 = new Ellipse2D.Double (130., 30., 150., 80.);       
      g2.setColor(Color.cyan);                                 
      g2.fill(ell1);                                            
      g2.setColor(Color.orange);                                
      g2.fill(ell2);                                            
      // Two ellipses with different colors plotted in XOR mode 
      ell1 = new Ellipse2D.Double (70., 140., 150., 80.);       
      ell2 = new Ellipse2D.Double (170., 140., 150., 80.);      
      g2.setXORMode(Color.white);                               
      g2.setColor(Color.cyan);                                 
      g2.fill(ell1);                                            
      g2.setColor(Color.magenta);                                
      g2.fill(ell2);                                            
      // Two ellipses with the same color plotted in XOR mode   
      ell1 = new Ellipse2D.Double (110., 250., 150., 80.);      
      ell2 = new Ellipse2D.Double (210., 250., 150., 80.);      
      g2.setXORMode(Color.white);                               
      g2.setColor(Color.cyan);                                 
      g2.fill(ell1);                                            
      g2.setColor(Color.cyan);                                 
      g2.fill(ell2);                                            
      super.setBackground( Color.white );
    }
    public static void main(String s[]) 
    {
      // Create a Window Listener to handle "close" events
      WindowListener l = new WindowAdapter()
      {
        public void windowClosing(WindowEvent e) 
        { 
            e.getWindow().dispose();
            System.exit(0); 
        }
      };
      // Create a blank yellow JPanel to use as canvas
      XORMode xm = new XORMode();
      // Create a frame and place the canvas in the center
      // of the frame.
      JFrame f = new JFrame("TestXORMode...");
      f.addWindowListener(l);
      f.add(xm, BorderLayout.CENTER);
      f.pack();
      
      xm.paintComponent(f.getGraphics());
      f.setSize(400,400);
      f.setVisible(true);
    }
}
