import java.awt.*;
import javax.swing.*;

public class NullLayoutExample extends Panel
{
    public static void main(String[] argv)
    {
        JFrame   f = new JFrame("Absolute positioning");
        f.setLayout(new GridLayout());
        f.add(new NullLayoutExample());
        f.pack();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }
    private void buttonHelper(String buttonText, int moveX, int moveY, 
       int width, int height)
    {
        JButton b = new JButton( buttonText ); 
        b.setBounds(moveX, moveY, width, height); 
        add(b);
    }
    NullLayoutExample()
    {
        setLayout(null);
        buttonHelper("Button 1", 10, 50, 60, 20); 
        buttonHelper("Button 2", 50, 10, 50, 30);
        buttonHelper("Button 3", 80, 40, 80, 20);
        buttonHelper("Button 4", 30, 100, 45, 25);
        buttonHelper("Button 5", 100, 50, 60, 20);
    }

    public Dimension getPreferredSize()
    {
        return new Dimension(200, 150);
    }
}
