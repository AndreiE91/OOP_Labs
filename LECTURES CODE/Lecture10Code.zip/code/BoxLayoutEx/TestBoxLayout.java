import java.awt.*;
import javax.swing.*;
/**
 * Write a description of class TestBoxLayout here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TestBoxLayout
{
    private static void addAButton(String text, Container container) 
    {
        JButton button = new JButton(text);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        container.add(button);
    }
    public static void main(String[] args)
    {
        JFrame jf = new JFrame("TestBoxLayout");
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.setSize(new Dimension( 200, 200));
        jf.setLocation(300, 300);

        // Create a new panel
        JPanel p = new JPanel();
        // Set the layout manager
        p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
        // Add buttons
        // leave some vertical space
        p.add( Box.createRigidArea(new Dimension(20,5)) );
        addAButton( "Button 1", p );
        // space between buttons
        p.add( Box.createRigidArea(new Dimension(5,20)) );
        addAButton( "Button 2", p );
        p.add( Box.createRigidArea(new Dimension(7,5)) );
        addAButton( "Button 3", p );
        p.add( Box.createHorizontalGlue() );
        addAButton( "Button 4", p );

        p.setBackground(Color.cyan);
        // Add the new panel to the existing container
        jf. add( p );
        jf.setVisible(true);
    }
}
