import java.awt.Container;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
/**
 * Write a description of class TestFlowLayout here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TestFlowLayout extends JPanel
{
    // instance variables - replace the example below with your own
     /**
     * Constructor for objects of class TestFlowLayout
     */
    public TestFlowLayout()
    {
        setLayout(new FlowLayout(FlowLayout.CENTER,20,15));
        addAButton("Button 1", this);
        addAButton("Long Button 2", this);
        addAButton("Button 3", this);
        addAButton("Button 4", this);
        addAButton("B5", this);
    }
    private static void addAButton(String text, Container container) 
    {
        JButton button = new JButton(text);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        container.add(button);
    }
    
    public static void main(String[] args) 
    {
        JFrame jf = new JFrame("TestFlowLayout");
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        TestFlowLayout tfl = new TestFlowLayout();
        jf.add(tfl);
        jf.pack(); // perform the layout
        jf.setSize(new Dimension(200, 200)); //call after performing layout
        jf.setLocationRelativeTo(null); // center window on screen. Call after pack
        jf.setVisible(true);

    }
}
