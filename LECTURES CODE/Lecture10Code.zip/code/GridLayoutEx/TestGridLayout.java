import java.awt.Container;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
/**
 * Write a description of class TestGridLayout here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TestGridLayout extends JPanel
{
    /**
     * Constructor for objects of class TestGridLayout
     */
    public TestGridLayout()
    {
        setLayout(new GridLayout(4, 3));
        for (int i = 1; i < 10; i++)
            addAButton(Integer.toString(i), this);
        addAButton("0", this);
        addAButton(".", this);
        addAButton("CE", this);
    }
    private static void addAButton(String text, Container container) 
    {
        JButton button = new JButton(text);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        container.add(button);
    }
    
    public static void main(String[] args) 
    {
        JFrame jf = new JFrame("TestGridLayout");
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        TestGridLayout tfl = new TestGridLayout();
        jf.add(tfl);
        jf.pack(); // perform the layout
        jf.setSize(new Dimension(180, 200)); //call after performing layout
        jf.setLocationRelativeTo(null); // center window on screen. Call after pack
        jf.setVisible(true);

    }
}
