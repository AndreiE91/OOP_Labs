

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class IconDemo extends JFrame implements ActionListener
{
    public static final int WIDTH = 500;
    public static final int HEIGHT = 200;
    public static final int TEXT_FIELD_SIZE = 30;

    private JTextField message;
    private JLabel dukeLabel;
    private ImageIcon[] dukeIcons;

    public static void main(String[] args)
    {
        IconDemo iconGui = new IconDemo( );
        iconGui.setLocationRelativeTo(null);
        iconGui.setVisible(true);
    }


    public IconDemo( )
    {
        super("Icon Demonstration");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setBackground(Color.WHITE);
        setLayout(new BorderLayout( ));

        dukeLabel = new JLabel("Mood check");
        dukeIcons = new ImageIcon[] {
            new ImageIcon("duke.gif"),
            new ImageIcon("duke_waving.gif"), 
            new ImageIcon("duke_standing.gif")
        };
        dukeLabel.setIcon(dukeIcons[0]);
        add(dukeLabel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel( );
        buttonPanel.setLayout(new FlowLayout( ));
        JButton happyButton = new JButton("Happy");
        ImageIcon happyIcon = new ImageIcon("smiley.gif");
        happyButton.setIcon(happyIcon);
        happyButton.addActionListener(this);
        buttonPanel.add(happyButton);
        JButton sadButton = new JButton("Sad");
        ImageIcon sadIcon = new ImageIcon("sad.gif");
        sadButton.setIcon(sadIcon);
        sadButton.addActionListener(this);
        buttonPanel.add(sadButton);
        add(buttonPanel, BorderLayout.SOUTH);

        message = new JTextField(TEXT_FIELD_SIZE);
        add(message, BorderLayout.CENTER);
    }


    public void actionPerformed(ActionEvent e)
    {
       String actionCommand = e.getActionCommand( );

       if (actionCommand.equals("Happy"))
       {
           dukeLabel.setIcon(dukeIcons[1]);
           message.setText(
                   "Smile and the world smiles with you!");
       }
       else if (actionCommand.equals("Sad"))
       {
           dukeLabel.setIcon(dukeIcons[2]);
           message.setText(
                  "Cheer up. It can't be that bad.");
       }
       else
            message.setText("Unexpected Error.");
    }
}
