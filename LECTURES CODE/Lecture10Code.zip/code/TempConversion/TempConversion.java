 import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Formatter;

public class TempConversion extends JPanel
{

   // Instance variables
   private JLabel l1, l2;       // Labels
   private JTextField t1, t2;   // Text Fields
   private DegCHandler cHnd;    // ActionEvent handler
   private DegFHandler fHnd;    // ActionEvent handler
   private FocusHandler eHnd;   // FocusEvent handler
   // Initialization method
   public void init() {
      
      // Create ActionEvent handlers
      cHnd = new DegCHandler( this );
      fHnd = new DegFHandler( this );
      // Create FocusEventHandler
      eHnd = new FocusHandler();

      // Create a new high-level panel
      JPanel pHoriz = new JPanel();
      pHoriz.setLayout(new BoxLayout(pHoriz, BoxLayout.X_AXIS));
      add( pHoriz );

      // Create two subordinate panels
      JPanel pVertL = new JPanel();
      JPanel pVertR = new JPanel();
      pVertL.setLayout(new BoxLayout(pVertL, BoxLayout.Y_AXIS));
      pVertR.setLayout(new BoxLayout(pVertR, BoxLayout.Y_AXIS));
      
      // Add to pHoriz with a horizontal space between panels
      pHoriz.add( pVertL );
      pHoriz.add( Box.createRigidArea(new Dimension(20,0)) );
      pHoriz.add( pVertR );
      
      // Create degrees Celsius field
      l1 = new JLabel("deg C:", JLabel.RIGHT);
      pVertL.add( l1 );
      t1 = new JTextField("0.0",15);
      t1.addActionListener( cHnd );
      t1.addFocusListener( eHnd );
      pVertR.add( t1 );

      // Create degrees Fahrenheight field
      l2 = new JLabel("deg F:", JLabel.RIGHT);
      pVertL.add( l2 );
      t2 = new JTextField("32.0",15);
      t2.addActionListener( fHnd );
      t2.addFocusListener( eHnd );
      pVertR.add( t2 );
   }
   
   // Method to convert deg F to deg C
   // and display result
   public void toC( double degF ) {
      double degC = (5. / 9.) * (degF - 32); 
      t1.setText( formatIt("%5.1f", degC) );
      t2.setText( formatIt("%5.1f", degF) );
   }
   // formats double arg according to fmtStr specs
   private String formatIt( String fmtStr, double arg)
   {
     Formatter fmt = new Formatter();
     return fmt.format(fmtStr, arg).toString();
   }
       
   
   // Method to convert deg C to deg F
   // and display result
   public void toF( double degC ) {
      double degF = (9. / 5.) * degC + 32; 
      t1.setText( formatIt("%5.1f", degC) );
      t2.setText( formatIt("%5.1f",degF) );
   }

   // Main method to create frame
   public static void main(String s[]) {

      // Create a frame to hold the application
      JFrame fr = new JFrame("TempConversion ...");
      fr.setSize(250,100);
      
      // Create a Window Listener to handle "close" events
      fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      // Create and initialize a TempConversion object
      TempConversion tf = new TempConversion();
      tf.init();
      
      // Add the object to the center of the frame
      fr.getContentPane().add(tf, BorderLayout.CENTER);
      fr.setLocationRelativeTo(null);
      // Display the frame
      fr.setVisible( true );
   }
}
class FocusHandler implements FocusListener
{
   public void focusGained(FocusEvent e) 
   {
      // System.out.println(e.getSource().getClass().getName());
      if (e.getSource().getClass().getName().endsWith("JTextField"))
      {
        JTextField t = (JTextField) e.getSource();
        t.setSelectionStart(0);
        t.setSelectionEnd(t.getText().length());
      }
   }
   public void focusLost(FocusEvent e)
   {
      if (e.getSource().getClass().getName().endsWith("JTextField"))
      {
        JTextField t = (JTextField) e.getSource();
        t.setSelectionStart(0);
        t.setSelectionEnd(0);
    }
   }
}
class DegCHandler implements ActionListener 
{
   private TempConversion tc;
   
   // Constructor 
   public DegCHandler( TempConversion t ) { tc = t; }
   
   // Execute when an event occurs
   public void actionPerformed( ActionEvent e ) 
   {
      String input = e.getActionCommand();
      double degC = new Double(input).doubleValue();
      tc.toF( degC );
   }
}
class DegFHandler implements ActionListener 
{
   private TempConversion tc;
   
   // Constructor 
   public DegFHandler( TempConversion t ) { tc = t; }
   
   // Execute when an event occurs
   public void actionPerformed( ActionEvent e ) 
   {
      String input = e.getActionCommand();
      double degF = new Double(input).doubleValue();
      tc.toC( degF );
   }
}
