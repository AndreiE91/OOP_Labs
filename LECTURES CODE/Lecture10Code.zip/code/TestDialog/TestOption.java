import javax.swing.JFrame;
import javax.swing.JOptionPane;
/**
 * Write a description of class TestOption here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TestOption
{
    public static void main(String[] args)
    {
        JFrame jf= new JFrame("Test option pane");
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.setSize(400, 200);
        jf.setVisible(true);
                   
        Object[] options = { "Okay", "Quit" };
        JOptionPane.showOptionDialog(null, "Choose one option", "Warning", 
        JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
            null, options, options[1]);

        Object[] possibleValues = { "First", "Second", "Third" };
        Object selectedValue = JOptionPane.showInputDialog(null, 
            "Pick one alterative", "Choose from the list",
            JOptionPane.INFORMATION_MESSAGE, null,
            possibleValues, possibleValues[2]);
        JOptionPane.showInternalConfirmDialog(jf.getContentPane(), 
            "please choose one", "information",
            JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);
   }

}
