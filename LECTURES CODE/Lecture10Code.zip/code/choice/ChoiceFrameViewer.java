import javax.swing.JFrame;

/**
   This program tests the ChoiceFrame.
*/
public class ChoiceFrameViewer
{  
   public static void main(String[] args)
   {  
      JFrame jf = new ChoiceFrame("Choice Demo");
      jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      jf.setLocationRelativeTo(null); // center window on screen. Call after pack
      jf.setVisible(true);      
   }
}

