import javax.swing.JFrame;

/**
   This program tests the MenuFrame.
*/
public class MenuFrameViewer
{  
   public static void main(String[] args)
   {  
      JFrame jf = new MenuFrame();
      jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      jf.setLocationRelativeTo(null);
      jf.setVisible(true);      
   }
}

