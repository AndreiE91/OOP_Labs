Big Java & Java Concepts example project "menu"

You can use this project as follows:

 - invoke the main method of the driver class MenuFrameViewer by 
 right-clicking on the class representation and selecting the main method.
  
This project illustrates concepts covered in Big Java & Java Concepts, Chapter 14 
"Graphical User Interfaces".

 - to use inheritance to customize panels and frames
 - to understand how user interface components are added to a container
 - to understand the use of layout managers to arrange user interface components in a container 
 - to become familiar with common user interface components such as buttons, text components, combo boxes, and menus 
 - to build programs that handle events from user interface components 
 - to learn how to browse the Java documentation