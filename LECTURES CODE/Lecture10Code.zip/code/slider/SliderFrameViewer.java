import javax.swing.JFrame;

public class SliderFrameViewer
{  
   public static void main(String[] args)
   {  
      SliderFrame jf = new SliderFrame("Slider Demo");
      jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      jf.setLocationRelativeTo(null); // center window on screen.
      jf.setVisible(true);
   }
}

