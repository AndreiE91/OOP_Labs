import java.util.*; 
// java FindDups i came i saw i learned


public class FindDups { 
   public static void main(String args[]) {   
      Set<String> s = new HashSet<String>(); 
      for (String a : args) 
        if (!s.add(a))
          System.out.println("Duplicat: " + a);
      System.out.println(s.size()+" cuvinte distincte: "+s); 
   } 
} 




