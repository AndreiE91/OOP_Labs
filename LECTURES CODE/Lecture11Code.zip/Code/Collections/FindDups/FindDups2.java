import java.util.*; 
// java FindDups i came i saw i learned


public class FindDups2 { 
   public static void main(String args[]) {   
       Set<String> uniques = new HashSet<String>();
      Set<String> dups = new HashSet<String>();
      for (String a : args) 
            if (!uniques.add(a)) dups.add(a);

        // Diferenta de multimi distructiva
        uniques.removeAll(dups); 
        System.out.println("Cuvinte unice:    " + uniques);
        System.out.println("Cuvinte duplicate: " + dups);
   } 
} 


