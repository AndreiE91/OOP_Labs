import javax.swing.JApplet;
import javax.swing.JPanel;
import java.awt.GridLayout;
import java.awt.Color;
import javax.swing.JMenu;
import javax.swing.JPopupMenu;
import javax.swing.JMenuItem;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.event.MouseInputAdapter;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;

public class AppletMenuDemo extends JApplet 
                            implements ActionListener
{
    public static final int WIDTH = 300;
    public static final int HEIGHT = 200;

    private JPanel redPanel;
    private JPanel yellowPanel;
    private JPanel bluePanel;
    private JPopupMenu popMenu;
    private JPanel which;
    class MyMouseAdapter extends MouseInputAdapter
    {
       public void mouseClicked(MouseEvent e) 
       {
           //if (e.isPopupTrigger()) 
               popMenu.show(e.getComponent(), e.getX(), e.getY());
               
       }
       public void mouseEntered(MouseEvent e) {};
       public void mouseExited(MouseEvent e) {}; 
       public void mouseDragged(MouseEvent e) {};
       public void mouseMoved(MouseEvent e) {}; 
    }    

    public void init( )
    {
        setLayout(new GridLayout(1, 3));
        MyMouseAdapter ma = new MyMouseAdapter();
        
        bluePanel = new JPanel( );
        bluePanel.setBackground(Color.LIGHT_GRAY);
        bluePanel.addMouseListener(ma);
        add(bluePanel);
        

        yellowPanel = new JPanel( );
        yellowPanel.setBackground(Color.LIGHT_GRAY);
        yellowPanel.addMouseListener(ma);
        add(yellowPanel);

        redPanel = new JPanel( );
        redPanel.setBackground(Color.LIGHT_GRAY);
        yellowPanel.addMouseListener(ma);
        add(redPanel);

        JMenu colorMenu = new JMenu("Add Colors");

        JMenuItem blueChoice = new JMenuItem("Blue");
        blueChoice.addActionListener(this);
        colorMenu.add(blueChoice);
        JMenuBar bar = new JMenuBar( );
        bar.add(colorMenu);
        setJMenuBar(bar);
        
        JMenuItem yellowChoice = new JMenuItem("Yellow");
        yellowChoice.addActionListener(this);
        colorMenu.add(yellowChoice);

        JMenuItem redChoice = new JMenuItem("Red");
        redChoice.addActionListener(this);
        colorMenu.add(redChoice);
        
        popMenu = new JPopupMenu(); //has no title
        JMenuItem clearChoice = new JMenuItem("Clear");
        clearChoice.addActionListener(new ActionListener()
        { // will claer all tyhree panels to LIGHT gray
            public void actionPerformed(ActionEvent e) {
               bluePanel.setBackground(Color.LIGHT_GRAY);
               redPanel.setBackground(Color.LIGHT_GRAY);
               yellowPanel.setBackground(Color.LIGHT_GRAY);
            };
        });
        JMenuItem paintAllChoice = new JMenuItem("Paint all");
        paintAllChoice.addActionListener(new ActionListener()
        { // will paint panels with Romanian flag colors
            public void actionPerformed(ActionEvent e) {
               bluePanel.setBackground(Color.BLUE);
               redPanel.setBackground(Color.RED);
               yellowPanel.setBackground(Color.YELLOW);
            };
        });
        
        popMenu.add(clearChoice);
        popMenu.add(paintAllChoice);
        
    }
    
    public void actionPerformed(ActionEvent e)
    {
        String buttonString = e.getActionCommand( );

        if (buttonString.equals("Red"))
             redPanel.setBackground(Color.RED);
        else if (buttonString.equals("Yellow"))
            yellowPanel.setBackground(Color.YELLOW);
        else if (buttonString.equals("Blue"))
            bluePanel.setBackground(Color.BLUE);
        else
            System.out.println("Unexpected error.");
    }
}
