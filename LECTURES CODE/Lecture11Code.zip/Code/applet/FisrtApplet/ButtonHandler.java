import java.awt.*;   
import java.awt.event.*;

class ButtonHandler implements ActionListener 
{
   private FirstApplet fa;
  // Constructor
   public ButtonHandler ( FirstApplet fa1 )
  {
      fa = fa1;
   }
   // Execute when an event occurs
   public void actionPerformed( ActionEvent e ) 
  {
      fa.updateLabel();
   }
}
