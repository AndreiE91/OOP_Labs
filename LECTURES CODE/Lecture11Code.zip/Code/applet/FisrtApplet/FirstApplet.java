import java.awt.*;   
import java.awt.event.*;
import javax.swing.*;
public class FirstApplet extends JApplet {
   // Instance variables
   private int count = 0;              // Numarul de apasari
   private JButton pushButton; // Buton care se apasa
   private JLabel label;               // Eticheta 
   // Initialization method
   public void init() {
       // Set the layout manager
      getContentPane().setLayout( new BorderLayout() );
      // Create a label to hold push count
      label = new JLabel("Push Count: 0");
      getContentPane().add( label, BorderLayout.NORTH );
      label.setHorizontalAlignment( label.CENTER );
      // Create a button
      pushButton = new JButton("Test Button");
      pushButton.addActionListener( new ButtonHandler(this) );
      getContentPane().add( pushButton, BorderLayout.SOUTH );
   }
  // Method to update push count
   public void updateLabel() {   label.setText( "Push Count: " + (++count) );    }
}
