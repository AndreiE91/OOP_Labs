// An applet that says "JApplet Demo..." in a big bold font,
// with three buttons to change the color of the message.

import java.awt.*;         // Defines basic classes for GUI programming.
import java.awt.event.*;   // Defines classes for working with events.
import java.awt.geom.*;    // Defines clases for two-dimensional geometry
import javax.swing.*;      // Defines the Swing GUI classes.


public class HelloWorldJApplet
                  extends JApplet implements ActionListener {
        // Defines a subclass of JApplet.  "Implements ActionListener"
        // says that objects of type HelloWorldJApplet are
        // capable of listening for ActionEvents.  This is necessary
        // if the applet is to respond to events from the buttons.


   Display display;  // A JPanel belonging to the following nested
                     // class; used for displaying "JApplet Demo...."


   class Display extends JPanel {
        // This nested class defines a component that displays
        // the string "JApplet Demo...".  The color and font for
        // the string are recorded in the variables colorNum
        // and textFont.
        
      int colorNum;     // Keeps track of which color is displayed;
                        //     1 for red, 2 for green, 3 for blue.

      Font textFont;    // The font in which the message is displayed.
                        // A font object represents a certain size and
                        // style of text drawn on the screen.
                        
      Display() 
      {
            // Constructor for the Display class.  Set the background
            // color and assign initial values to the instance
            // variable, colorNum and textFont.
         setBackground(Color.white);
         colorNum = 1;   // The color of the message is set to red.
         textFont = new Font("Serif",Font.BOLD,36);
             // Create a font object representing a big, bold font.
         setSize(new Dimension(200, 300));
      }
      
      void setColor(int code) 
      {
            // This method is provided to be called by the
            // main class when it wants to set the color of the
            // message.  The parameter value should be 1, 2, or 3
            // to indicate the desired color.
         colorNum = code;
         repaint(); // Tell the system to repaint this component.
      }

      public void paintComponent(Graphics g)
      {
            // This routine is called by the system whenever this JPanel
            // needs to be drawn or redrawn.  It first calls 
            // super.paintComponent() to fill the panel with the
            // background color.  It then displays the message
            // "JApplet Demo..." in the proper color and font.
         super.paintComponent(g);
         switch (colorNum) {         // Set the color.
            case 1:
               g.setColor(Color.red);
               break;
            case 2:
               g.setColor(Color.green);
               break;
            case 3:
               g.setColor(Color.blue);
               break;
         }
         g.setFont(textFont);       // Set the font.
         // find location for centering text
         Dimension d = getSize(); 
         FontMetrics fm = g.getFontMetrics();
         int w = fm.stringWidth("JApplet Demo..");
         int x = (d.width - w)/2;
         int y = (d.height + fm.getHeight()/2)/2;
         g.drawString("JApplet Demo...", x, y);    // Draw the message.
      } // end paintComponent

   } // end nested class Display


   public void init() 
   {
          // This is called by the system to initialize the applet.
          // It adds a button to the "south" position in the applet's
          // content pane, and it adds a display panel to the "center"
          // position so that it will fill the rest of the content pane.

       display = new Display();
             // The component that displays "JApplet Demo...".

       getContentPane().add(display, BorderLayout.CENTER);
             // Adds the display panel to the CENTER position of the
             // JApplet's content pane.

       JPanel buttonBar = new JPanel();
             // This panel will hold three buttons and will appear
             // at the bottom of the applet.
             
       buttonBar.setBackground(Color.gray);
             // Change the background color of the button panel 
             // so that the buttons will stand out better.
       
       JButton redButton = new JButton("Red");
             // Create a new button.  "Red" is the text
             // displayed on the button.

       redButton.addActionListener(this);  
             // Set up the button to send an "action event" to this applet
             // when the user clicks the button.  The parameter, this,
             // is a name for the applet object that we are creating,
             // so action events from the button will be handled by
             // calling the actionPerformed() method in this class.
             
       buttonBar.add(redButton);
             // Add the button to the buttonBar panel.
             
       JButton greenButton = new JButton("Green"); // the second button
       greenButton.addActionListener(this);
       buttonBar.add(greenButton);

       JButton blueButton = new JButton("Blue"); // the second button
       blueButton.addActionListener(this);
       buttonBar.add(blueButton);

       getContentPane().add(buttonBar, BorderLayout.SOUTH); 
             // Add button panel to the bottom of the content pane.

   }  // end init()


   public void actionPerformed(ActionEvent evt) {
         // This routine is called by the system when the user clicks
         // on one of the buttons.  The response is to set the display's
         // color accordingly.  

      String command = evt.getActionCommand();
               // The "action command" associated with the event 
               // is the text on the button that was clicked.
               
      if (command.equals("Red"))       // Set the color.
         display.setColor(1);
      else if (command.equals("Green"))
         display.setColor(2);
      else if (command.equals("Blue"))
         display.setColor(3);

   }  // end actionPerformed()


} // end class HelloWorldJApplet

