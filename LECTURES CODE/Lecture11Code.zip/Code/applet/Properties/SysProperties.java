// "Java Tech"
//  Code provided with book for educational purposes only.
//  No warranty or guarantee implied.
//  This code freely available. No copyright claimed.
//  2003
//

// Begun from Start_JApplet8

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;


public class SysProperties extends JApplet
             implements ActionListener
{
  // A Swing textarea for display of string info
  JTextArea fTextArea = null;

  public void init () {

    // Create a User Interface with a textarea with sroll bars
    // and a Go button to initiate processing and a Clear button
    // to clear the textarea.
    Container content_pane = getContentPane ();

    JPanel panel = new JPanel (new BorderLayout ());

    // Create an instance of DrawingPanel
    fTextArea = new JTextArea ();

    // Create an instance of DrawingPanel
    fTextArea = new JTextArea ();
    fTextArea.setEditable (false);

    // Add to a scroll pane so that a long list of
    // computations can be seen.
    JScrollPane area_scroll_pane = new JScrollPane (fTextArea);

    panel.add (area_scroll_pane,"Center");

    JButton go_button = new JButton ("Go");
    go_button.addActionListener (this);

    JButton clear_button = new JButton ("Clear");
    clear_button.addActionListener (this);

    JPanel control_panel = new JPanel ();
    control_panel.add (go_button);
    control_panel.add (clear_button);

    panel.add (control_panel,"South");

    // Add text area with scrolling to the contentPane.
    content_pane.add (panel);

  }

  /**  Print out the system properties list. **/
  public void start () {

    try {
      Properties sysProps = System.getProperties ();
      int i=0;
      Enumeration enum1 = sysProps.propertyNames ();
      while  (enum1.hasMoreElements ())
      {
        String key =  (String)enum1.nextElement ();
        i++;
        print (i +". "+key+ " = " +
            sysProps.getProperty (key) + "\n");
      }
    } catch (Exception e){
      // If security error thrown by browser,
      // then only ask for the following key values.

      String [] key =  {
        "java.version",
        "java.vendor",
        "java.class.version",
        "os.name",
        "os.arch",
        "os.version",
        "file.separator",
        "path.separator",
        "line.separator",
      };

      for (int i=0; i<key.length; i++)
           print (i +". "+ key[i] + " = " +
              System.getProperty (key[i]) + "\n");
    }
  }

  /**  Respond to the buttons. **/
  public void actionPerformed (ActionEvent e) {
    if  (e.getActionCommand ().equals ("Go"))
        start ();
    else
        fTextArea.setText (null);
  }

  /**  Send println () output to the text area. **/
  public void println (String str) {
    fTextArea.append (str + '\n');
  }

  /**  Send print () output to the text area. **/
  public void print (String str) {
    fTextArea.append (str);
  }

  /**  Display the applet in a JFrame. **/
  public static void main (String[] args) {
    int frame_width=350;
    int frame_height=350;
    JApplet applet = new SysProperties ();
    applet.init ();

    // Creat a frame and add the applet to it.
    JFrame f = new JFrame ("Frame & Image Demo");

    f.getContentPane ().add ( applet);
    f.setSize (new Dimension (frame_width,frame_height));
    f.setVisible (true);

    applet.start ();
  }
} // class SysProperties
