// Squares.java

import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import javax.swing.*;

public class Squares extends JApplet
{
   private void createGUI ()
   {
      // Establish the GUI.

      getContentPane ().setLayout (new FlowLayout ());

      // Create the game-board component: each cell is 40 pixels on a side,
      // the square color is green, the component's border is blue when it
      // gets the focus, and the component's border is black when it loses the
      // focus. Add this component to the content pane.

      final GameBoard gb;
      gb = new GameBoard (40, Color.green, Color.blue, Color.black);
      getContentPane ().add (gb);

      // The rest of the GUI consists of two buttons. These buttons will be
      // placed in a panel so that they can be treated as a single unit. For
      // example, if the applet's width is made larger, both buttons (rather
      // than just one button) will appear to the right of the game board.

      JPanel p = new JPanel ();

      // Create the Change Square Color button and make sure it is disabled.
      // Square color should only be changed when a game is in play.

      final JButton btnChangeSquareColor = new JButton ("Change Square Color");
      btnChangeSquareColor.setEnabled (false);

      // Establish the Change Square Color button's action listener. When this 
      // button is clicked, it changes the square color to a randomly-chosen
      // color.

      ActionListener al;
      al = new ActionListener ()
           {
               public void actionPerformed (ActionEvent e)
               {
                  Random rnd = new Random ();

                  while (true)
                  {
                      int r = rnd.nextInt (256);
                      int g = rnd.nextInt (256);
                      int b = rnd.nextInt (256);

                      // Disallow colors where all color components are less
                      // than 192. Dark colors lead to poor contrast when
                      // black is the background color.

                      if (r < 192 && g < 192 && b < 192)
                          continue;

                      gb.changeSquareColor (new Color (r, g, b));

                      break;
                  }
               }
           };

      btnChangeSquareColor.addActionListener (al);

      p.add (btnChangeSquareColor);

      // Create the Start button.

      final JButton btnStart = new JButton ("Start");

      // Establish the Start button's action listener. When this button is
      // clicked, it disables itself (you cannot start a started game),
      // enables the Change Square Color button (you can change the square
      // color during game play), and starts the game. A done listener is
      // established to enable the Start button and disable the Change Square
      // Color button when the game ends.

      al = new ActionListener ()
           {
               public void actionPerformed (ActionEvent e)
               {
                  btnStart.setEnabled (false);
                  btnChangeSquareColor.setEnabled (true);

                  gb.start (new GameBoard.DoneListener ()
                            {
                                public void done ()
                                {
                                   btnStart.setEnabled (true);
                                   btnChangeSquareColor.setEnabled (false);
                                }
                            });
               }
           };

      btnStart.addActionListener (al);

      // Add both buttons, via the panel, to the content pane.

      p.add (btnStart);

      getContentPane ().add (p);

      // Under Java 1.4.0, it is not possible to tab the focus from one
      // component to another component without establishing the JApplet as a
      // focus cycle root, and establishing a focus traversal policy. You can
      // learn more about this bug by pointing your Web browser to the link
      // http://bugs.sun.com/bugdatabase/view_bug.do;:YfiG?bug_id=4705205.

      if (System.getProperty ("java.version").equals ("1.4.0"))
      {
          setFocusCycleRoot (true);
          setFocusTraversalPolicy (new LayoutFocusTraversalPolicy ());
      }
   }

   public void init ()
   {
      // According to Sun's Java Tutorial, Swing components should be created,
      // queried, and manipulated on the event-dispatching thread. Because
      // most Web browsers don't invoke significant applet methods, such as
      // public void init(), from that thread, SwingUtilities.invokeAndWait()
      // is called to ensure the GUI is created on the event-dispatching
      // thread. The invokeAndWait() method is used instead of invokeLater()
      // because the latter method could allow init() to return before the GUI
      // was made; this would result in difficult-to-debug applet problems.

      try
      {
          SwingUtilities.invokeAndWait (new Runnable ()
                                        {
                                            public void run ()
                                            {
                                               createGUI ();
                                            }
                                        });
      }
      catch (Exception e)
      {
          System.err.println ("Unable to create GUI");
      }
   }
}

class GameBoard extends JPanel
{
   // Game states.

   private final static int INITIAL = 0;
   private final static int INPLAY = 1;
   private final static int LOSE = 2;
   private final static int WIN = 3;

   // Size of border.

   private final static int BORDER_SIZE = 5;

   // Current game state.

   private int state = INITIAL;

   // Number of pixels between cell borders.

   private int cellSize;

   // Width of game board (plus borders).

   private int width;

   // Height of game board and message area (plus borders).

   private int height;

   // The color of each square.

   private Color squareColor;

   // The game board's focus border color.

   private Color focusBorderColor;

   // The game board's nonfocus border color.

   private Color nonfocusBorderColor;

   // The game board's current border color.

   private Color borderColor;

   // Cells: true means that the cell contains a colored square.

   private boolean [] cells = new boolean [9];

   // Reference to object that is listening for game to finish.

   private GameBoard.DoneListener dl;

   // Reference to a timer that counts down the timer counter, determines
   // whether the player has lost or won, and notifies the done listener when
   // either situation occurs.

   private Timer timer;

   // Timer counter.

   private int counter;

   // GameBoard constructor.

   GameBoard (int cellSize, Color squareColor, Color focusBorderColor,
              Color nonfocusBorderColor)
   {
      this.cellSize = cellSize;

      width = 3*cellSize+2+2*BORDER_SIZE;
      height = width + 50;

      setPreferredSize (new Dimension (width, height));

      this.squareColor = squareColor;


      this.focusBorderColor = focusBorderColor;


      this.nonfocusBorderColor = nonfocusBorderColor;

      this.borderColor = nonfocusBorderColor;

      addFocusListener (new FocusListener ()
                        {
                            public void focusGained (FocusEvent e)
                            {
                               borderColor = GameBoard.this.focusBorderColor;

                               repaint ();
                            }

                            public void focusLost (FocusEvent e)
                            {
                               borderColor = GameBoard.this.nonfocusBorderColor;

                               repaint ();
                            }
                        });

      addKeyListener (new KeyAdapter ()
                      {
                          public void keyTyped (KeyEvent e)
                          {
                             if (state != INPLAY)
                               return;

                             char key = e.getKeyChar ();

                             // If the player has typed a digit key, map that
                             // key to the cells array index, and toggle the
                             // appropriate square and its neighbors.

                             if (Character.isDigit (key))
                                 switch (key)
                                 {
                                    case '1': GameBoard.this.toggle (6);
                                              break;

                                    case '2': GameBoard.this.toggle (7);
                                              break;

                                    case '3': GameBoard.this.toggle (8);
                                              break;


                                    case '4': GameBoard.this.toggle (3);
                                              break;

                                    case '5': GameBoard.this.toggle (4);
                                              break;

                                    case '6': GameBoard.this.toggle (5);
                                              break;

                                    case '7': GameBoard.this.toggle (0);
                                              break;

                                    case '8': GameBoard.this.toggle (1);
                                              break;

                                    case '9': GameBoard.this.toggle (2);
                                 }
                          }
                      });

      addMouseListener (new MouseAdapter ()
                        {
                            public void mouseClicked (MouseEvent e)
                            {
                               if (state != INPLAY)
                                 return;

                               // When the mouse is clicked on the game board,
                               // make sure the game board receives focus so
                               // that the keyboard can be used as an
                               // alternative for toggling squares.

                               GameBoard.this.requestFocusInWindow ();

                               // Which cell was clicked?

                               int cell = GameBoard.this.
                                          mouseToCell (e.getX (), e.getY ());

                               // If a cell was clicked (cell != -1), toggle
                               // that cell's square and neighboring cell
                               // squares.

                               if (cell != -1)
                                   GameBoard.this.toggle (cell);
                            }
                        });

      setFocusable (true);
   }

   // Change current square color to new square color. IMPORTANT: Must be
   // called from the event-dispatching thread.

   void changeSquareColor (Color squareColor)
   {
      if (!SwingUtilities.isEventDispatchThread ())
          return;

      this.squareColor = squareColor;
      repaint ();
   }

   // Paint component: borders first, message last.

   public void paintComponent (Graphics g)
   {
      // It is always a good idea to invoke the superclass paintComponent()
      // method first.

      super.paintComponent (g);

      // Paint all four borders using the current border color.

      g.setColor (borderColor);
      for (int i = 0; i < BORDER_SIZE; i++)
           g.drawRect (i, i, width-2*i-1, height-2*i-1);

      // Paint the component's game board (less the borders and message area)
      // black.

      g.setColor (Color.black);
      g.fillRect (BORDER_SIZE, BORDER_SIZE, width-2*BORDER_SIZE,
                  width-2*BORDER_SIZE);

      // Paint horizontal grid lines.

      g.setColor (Color.white);
      g.drawLine (BORDER_SIZE, BORDER_SIZE+cellSize,
                  BORDER_SIZE+width-2*BORDER_SIZE-1, BORDER_SIZE+cellSize);

      g.drawLine (BORDER_SIZE, BORDER_SIZE+2*cellSize+1,
                  BORDER_SIZE+width-2*BORDER_SIZE-1, BORDER_SIZE+2*cellSize+1);

      // Paint vertical grid lines.

      g.drawLine (BORDER_SIZE+cellSize, BORDER_SIZE, BORDER_SIZE+cellSize,
                  BORDER_SIZE+width-2*BORDER_SIZE-1);

      g.drawLine (BORDER_SIZE+2*cellSize+1, BORDER_SIZE,
                  BORDER_SIZE+2*cellSize+1, BORDER_SIZE+width-2*BORDER_SIZE-1);

      // Paint the squares.

      g.setColor (squareColor);
      for (int i = 0; i < cells.length; i++)
      {
           if (cells [i])
           {                           
               int x = BORDER_SIZE+(i%3)*(cellSize+1)+3;
               int y = BORDER_SIZE+(i/3)*(cellSize+1)+3;

               int w = cellSize-6;
               int h = w;

               g.fillRect (x, y, w, h);
           }
      }

      // Paint the component's message area (below the game board, but still
      // within the borders) white.

      g.setColor (Color.white);
      g.fillRect (BORDER_SIZE, width-BORDER_SIZE, width-2*BORDER_SIZE,
                  height-width);

      // Paint a message if the game-board state is not the initial state.

      if (state != INITIAL)
      {
          g.setColor (Color.black);

          String text;

          switch (state)
          {
             case LOSE:
                  text = "YOU LOSE!";
                  break;

             case WIN:
                  text = "YOU WIN!";

                  break;

             default:
                  text = "" + counter;
          }

          g.drawString (text, (width-g.getFontMetrics ().stringWidth (text))/2,
                        width-BORDER_SIZE+30);
      }
   }

   // Start a new game, unless a game is in play. Register the done listener,
   // establish an initial pattern of colored squares, and begin a timer that
   // fires an action event every second. IMPORTANT: Must be called from the
   // event-dispatching thread.

   void start (GameBoard.DoneListener dl)
   {
      if (!SwingUtilities.isEventDispatchThread ())
          return;

      if (state == INPLAY)
          return;

      this.dl = dl;

      Random rnd = new Random ();

      while (true)
      {
         for (int i = 0; i < cells.length; i++)
              cells [i] = rnd.nextBoolean ();

         int counter = 0;
         for (int i = 0; i < cells.length; i++)
              if (cells [i])
                  counter++;

         if (counter != 0 && counter != cells.length)
             break;
      }

      ActionListener al;
      al = new ActionListener ()
           {
               public void actionPerformed (ActionEvent e)
               {
                  // If the player has won, notify the done listener.

                  if (state == WIN)
                  {
                      timer.stop ();
                      GameBoard.this.dl.done ();
                      return;
                  }

                  // When the counter reaches zero, the player has lost.
                  // Notify the done listener.

                  if (--counter == 0)
                  {
                      state = LOSE;
                      timer.stop ();
                      GameBoard.this.dl.done ();
                  }

                  repaint ();
               }
           };

      timer = new Timer (1000, al);

      state = INPLAY;
      counter = 30;
                
      timer.start ();
   }

   // Map mouse coordinates to cell number [0,8], or -1 if mouse coordinates
   // do not identify a cell.

   private int mouseToCell (int x, int y)
   {
       // Examine first column.

       if (x >= BORDER_SIZE && x < BORDER_SIZE+cellSize)
       {
           if (y >= BORDER_SIZE && y < BORDER_SIZE+cellSize)
               return 0;

           if (y >= BORDER_SIZE+cellSize+1 && y < BORDER_SIZE+2*cellSize+1)
               return 3;

           if (y >= BORDER_SIZE+2*cellSize+2 && y < BORDER_SIZE+3*cellSize+2)
               return 6;
       }

       // Examine second column.

       if (x >= BORDER_SIZE+cellSize+1 && x < BORDER_SIZE+2*cellSize+1)
       {
           if (y >= BORDER_SIZE && y < BORDER_SIZE+cellSize)
               return 1;

           if (y >= BORDER_SIZE+cellSize+1 && y < BORDER_SIZE+2*cellSize+1)
               return 4;

           if (y >= BORDER_SIZE+2*cellSize+2 && y < BORDER_SIZE+3*cellSize+2)
               return 7;
       }

       // Examine third column.

       if (x >= BORDER_SIZE+2*cellSize+2 && x < BORDER_SIZE+3*cellSize+2)
       {
           if (y >= BORDER_SIZE && y < BORDER_SIZE+cellSize)
               return 2;

           if (y >= BORDER_SIZE+cellSize+1 && y < BORDER_SIZE+2*cellSize+1)
               return 5;

           if (y >= BORDER_SIZE+2*cellSize+2 && y < BORDER_SIZE+3*cellSize+2)
               return 8;
       }

       return -1;
   }

   // Toggle a cell and its neighbors. Figure 1A in the article presents the
   // following map of cells from the numeric keypad perspective:
   //
   // 7 8 9
   // 4 5 6
   // 1 2 3
   //
   // Because the cells array is zero-based, it is more convenient to work
   // with the map below:
   //
   // 0 1 2
   // 3 4 5
   // 6 7 8
   //
   // Therefore, when toggle() is called, the calling code must convert the
   // digit key that was pressed (1-9) to an index (0-8) that corresponds to
   // the map above.

   private void toggle (int cell)
   {
      // Toggle the cells.

      switch (cell)
      {
         case 0: cells [0] = !cells [0];
                 cells [1] = !cells [1];
                 cells [3] = !cells [3];
                 cells [4] = !cells [4];
                 break;

         case 1: cells [0] = !cells [0];
                 cells [1] = !cells [1];
                 cells [2] = !cells [2];
                 break;

         case 2: cells [1] = !cells [1];
                 cells [2] = !cells [2];
                 cells [4] = !cells [4];
                 cells [5] = !cells [5];
                 break;

         case 3: cells [0] = !cells [0];
                 cells [3] = !cells [3];
                 cells [6] = !cells [6];
                 break;

         case 4: cells [0] = !cells [0];
                 cells [2] = !cells [2];
                 cells [4] = !cells [4];
                 cells [6] = !cells [6];
                 cells [8] = !cells [8];
                 break;

         case 5: cells [2] = !cells [2];
                 cells [5] = !cells [5];
                 cells [8] = !cells [8];
                 break;

         case 6: cells [3] = !cells [3];
                 cells [4] = !cells [4];
                 cells [6] = !cells [6];
                 cells [7] = !cells [7];
                 break;

         case 7: cells [6] = !cells [6];
                 cells [7] = !cells [7];
                 cells [8] = !cells [8];
                 break;

         case 8: cells [4] = !cells [4];
                 cells [5] = !cells [5];
                 cells [7] = !cells [7];
                 cells [8] = !cells [8];
      }

      // Find out if the player has won the game. This code is not placed in
      // the start() method's action listener (where the code for decrementing
      // the counter and determining if the player has lost -- the counter
      // reaches 0 -- exists) because it would then be possible for the player
      // to occasionally toggle all squares black and quickly untoggle them --
      // the player would win and possibly still lose. That behavior is not
      // desirable.

      int i;
      for (i = 0; i < cells.length; i++)
           if (cells [i])
               break;

      if (i == cells.length)
          state = WIN;

      // Draw game board with toggled cells.

      repaint ();
   }

   // Done listener interface. The start() method requires an object argument
   // whose class implements this interface.

   interface DoneListener
   {
      void done ();
   }
}