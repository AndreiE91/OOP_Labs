import java.awt.event.*;
import javax.swing.JApplet;
public class AppletWindowHandler extends WindowAdapter {
   JApplet ap;

   // Constructor
   public AppletWindowHandler ( JApplet a ) { ap = a; } 

   // This method implements a listener that detects
   // the "window closing event", shuts down the applet,
   // and stops the program.
   public void windowClosing(WindowEvent e) {
      ap.stop();
      ap.destroy();
      System.exit(0);
   };
}
