/*
   Purpose:
     This GUI-based program converts temperature in
     degrees Fahrenheit to degrees Celsius, and vice versa. 

   Record of revisions:
       Date       Programmer          Description of change
       ====       ==========          =====================
     10/14/98    S. J. Chapman        Original code
  1. 12/22/98    S. J. Chapman        Modified for for applet
*/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Formatter;

public class TempConversionApplet extends JApplet {

   // Instance variables
   private JLabel l1, l2;       // Labels
   private JTextField t1, t2;   // Text Fields
   private DegCHandler cHnd;    // ActionEvent handler
   private DegFHandler fHnd;    // ActionEvent handler

   // Initialization method
   public void init() {
      
      // Set the layout manager
      getContentPane().setLayout( new FlowLayout() );
      
      // Create ActionEvent handlers
      cHnd = new DegCHandler( this );
      fHnd = new DegFHandler( this );

      // Create degrees Celsius field
      l1 = new JLabel("deg C:", JLabel.RIGHT);
      getContentPane().add( l1 );
      t1 = new JTextField("0.0",15);
      t1.addActionListener( cHnd );
      getContentPane().add( t1 );

      // Create degrees Farenheit field
      l2 = new JLabel("deg F:", JLabel.RIGHT);
      getContentPane().add( l2 );
      t2 = new JTextField("32.0",15);
      t2.addActionListener( fHnd );
      getContentPane().add( t2 );
   }
   
   // Method to convert deg F to deg C
   // and display result
   public void toC( double degF ) {
      double degC = (5. / 9.) * (degF - 32); 
      t1.setText( sprintf("%5.1f",degC) );
      t2.setText( sprintf("%5.1f",degF) );
   }
   // Method to imitate sprintf
   private String sprintf(String format, Object val)
   {
       Formatter fmt = new Formatter();
       return fmt.format(format, val).toString();
   }
       
   // Method to convert deg C to deg F
   // and display result
   public void toF( double degC ) {
      double degF = (9. / 5.) * degC + 32; 
      t1.setText( sprintf("%5.1f",degC) );
      t2.setText( sprintf("%5.1f",degF) );
   }

   // Main method to create frame
   public static void main(String s[]) {

      // Create a frame to hold the application
      JFrame fr = new JFrame("TempConversionApplet ...");
      fr.setSize(250,100);
      
      // Create and initialize a TempConversionApplet object
      TempConversionApplet tc = new TempConversionApplet();
      tc.init();
      tc.start();
      
      // Create a Window Listener to handle "close" events
      AppletWindowHandler l = new AppletWindowHandler(tc);
      fr.addWindowListener(l);

      // Add the object to the center of the frame
      fr.getContentPane().add(tc, BorderLayout.CENTER);

      // Display the frame
      fr.setVisible( true );
   }
}

class DegCHandler implements ActionListener {
   private TempConversionApplet tc;
   
   // Constructor 
   public DegCHandler( TempConversionApplet t ) { tc = t; }
   
   // Execute when an event occurs
   public void actionPerformed( ActionEvent e ) {
      String input = e.getActionCommand();
      double degC = new Double(input).doubleValue();
      tc.toF( degC );
   }
}

class DegFHandler implements ActionListener {
   private TempConversionApplet tc;
   
   // Constructor 
   public DegFHandler( TempConversionApplet t ) { tc = t; }
   
   // Execute when an event occurs
   public void actionPerformed( ActionEvent e ) {
      String input = e.getActionCommand();
      double degF = new Double(input).doubleValue();
      tc.toC( degF );
   }
}
