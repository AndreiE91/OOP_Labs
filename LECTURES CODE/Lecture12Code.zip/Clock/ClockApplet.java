// "Java Tech"
//  Code provided with book for educational purposes only.
//  No warranty or guarantee implied.
//  This code freely available. No copyright claimed.
//  2003
//
//

// Begun from StartJApplet6

/*
 <applet code="ClockApplet.class" width=300 height=300>
  </applet>
*/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
  * This applet implements Runnable and uses a thread
  *   to create a digital clock.
 **/
public class ClockApplet extends JApplet
                       implements Runnable{
  // Will use thread reference as a flag
  Thread fThread = null;
    class ActList implements ActionListener {
    public void actionPerformed(ActionEvent e){
        Graphics g = getGraphics();
        if (e.getActionCommand().equals("B1"))
            g.drawString(e.getActionCommand(), 10,10);
        else
            g.drawString(e.getActionCommand(), 10,30);
    }
}
  // Need panel reference in run ().
  DateFormatPanel fClockPanel = null;

  public void init () {
    Container content_pane = getContentPane ();

    // Create an instance of the time panel
    fClockPanel = new DateFormatPanel ();
    content_pane.setLayout(new BorderLayout());
    // Add the time panel to the applet's panel.
    JPanel jp = new JPanel();
    JButton b1 = new JButton("B1");
    JButton b2 = new JButton("B2");
    jp.add(b1);
    jp.add(b2);
    ActList al = new ActList();
    b1.addActionListener(al);
    b2.addActionListener(al);
    content_pane.add(jp, BorderLayout.NORTH);
    content_pane.add (fClockPanel, BorderLayout.CENTER);
  } // init

  // This method called by browser when web page and
  // applet loaded.
  public void start () {
    // If the thread reference not null then a
    // thread is already running. Otherwise, create
    // a thread and start it.
    if (fThread == null){
        fThread = new Thread (this);
        fThread.start ();
    }
  } // start

  // This method called by browser when web page and
  // applet loaded.
  public void stop () {
    // Setting thread to null will cause loop in
    // run () to finish and kill the thread.
    fThread = null;
  } // stop

  public void run () {
    // Loop through sleep periods until
    // thread stopped by setting thread
    // reference to null.
    while (fThread != null) {
      try{
        Thread.sleep (1000);
      } catch  (InterruptedException e) { }

      // Repaint clock
        fClockPanel.repaint ();
    }
  } // run

} // class ClockApplet
