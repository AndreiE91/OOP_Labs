/* & lt Applet code = MoveItDB
     width = 300 height = 300 >
   < /Applet >
*/

import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class MoveItDB extends Applet implements ActionListener, 
                                     AdjustmentListener, Runnable {

   Button StartButton;
   int init_x = 50;
   int init_y = 50;
   int rect_width = 50;
   int rect_height = 20;
   int x;
   int y;
   int num = 100;
   int delay = 100;
   Thread move_thread;
   Label DelayLabel;
   Scrollbar DelayValue;
   Image buffer;
   Graphics GC;
   Graphics GCback;
   int width;
   int height;

   public void init() {
      Panel p = new Panel();
      Panel q = new Panel();
      p.setLayout(new GridLayout(2,1));
      q.setLayout(new GridLayout(1,2));
      setBackground(Color.lightGray);
      setLayout(new BorderLayout());
      StartButton = new Button("Start");
      DelayLabel = new Label("Delay "+delay);
      q.add(DelayLabel);
      DelayValue = new Scrollbar(Scrollbar.HORIZONTAL,delay,10,0,1010);
      DelayValue.addAdjustmentListener(this);
      q.add(DelayValue);
      p.add(q);
      p.add(StartButton);
      add("South",p);
      StartButton.addActionListener(this);
      x = init_x;
      y = init_y;
      width = getBounds().width;
      height = getBounds().height;
      buffer = createImage(width,height);
      GC = buffer.getGraphics();
      GCback = buffer.getGraphics();
      GC.setColor(Color.red);
      GCback.setColor(Color.yellow);
   }

   public void update(Graphics g) {
      paint(g);
   }

   public void paint(Graphics g) {
      GCback.fillRect(0,0,width,height);
      GC.fillRect(x,y,rect_width,rect_height);
      g.drawImage(buffer,0,0,this);
   }

   public void stop() {
      if (move_thread != null)
         move_thread.suspend();
   }

   public void start() {
       if (move_thread != null)
          move_thread.resume();
   }

   public void run() {
      try {
         for(int i=0;i < num;i++) {
            x++;
            y++;
            repaint(1);
            Thread.sleep(delay);
         }
      }  catch (InterruptedException e) {
         return;                 // end this thread
      }
   }

   public void actionPerformed(ActionEvent e) {
      if (e.getSource() == StartButton) {
         x = init_x;
         y = init_y;
         move_thread = new Thread(this);
         move_thread.start();
      }
   }

   public void adjustmentValueChanged(AdjustmentEvent e) {
      delay = DelayValue.getValue();
      DelayLabel.setText("Delay "+delay);
   }
}
