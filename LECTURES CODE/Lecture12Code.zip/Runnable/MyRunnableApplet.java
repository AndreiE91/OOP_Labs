// "Java Tech"
//  Code provided with book for educational purposes only.
//  No warranty or guarantee implied.
//  This code freely available. No copyright claimed.
//  2003
//

/*
 <applet code="MyRunnableApplet.class" width=300 height=300>
  </applet>
*/
import java.awt.Graphics;
import java.awt.Color;
/** Demo threading with Runnable implementation. **/
public class MyRunnableApplet extends java.applet.Applet
                              implements Runnable {
  Graphics g;
  int x = 0;
  /** Applet's start method creates a thread and lets it run for 2 secs.**/
  public void start () {

    // Create an instance of Thread with a
    // reference to this Runnable instance.
    Thread myThread = new Thread (this);
    g = getGraphics();
    // Start the thread
    myThread.start ();
    x = 1;
    repaint();
  } // start

  /** Override the Runnable run() method. **/
  public void run() {
     int count = 0;

     while (true) {
        // System.out.println ("Thread 2 alive");
        g.drawString("Thread 2 alive", 200, 
            20 + (count * 10) % (this.getHeight()-20));
        // Print every 0.10sec for 5 seconds
        try{
           Thread.sleep(200);
       } catch (InterruptedException e) {}
       count++;
       if ( count >= 50 ) break;
     }
     g.setColor(Color.red);
     g.drawString("Thread stopping", 400, 100);
  } // run

  public void paint(java.awt.Graphics g) {
    g.drawString("Thread demo 2", 20, 20);
    if ( x > 0) g.drawOval(30,30,40,50);
  }

} // class MyRunnableApplet
