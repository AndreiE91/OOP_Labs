// "Java Tech"
//  Code provided with book for educational purposes only.
//  No warranty or guarantee implied.
//  This code freely available. No copyright claimed.
//  2003
//

public class MyThread extends Thread {
  public void run () {
    int count = 0;

    while (true) {

       System.out.println ("Thread 1 alive");

       // Print every 0.10sec for 2 seconds
       try {
           Thread.sleep (100);
       } catch (InterruptedException e) {}

       count++;
       if (count >= 20) break;
    }

    System.out.println ("Thread stopping");
  } // run
} // class MyThread
