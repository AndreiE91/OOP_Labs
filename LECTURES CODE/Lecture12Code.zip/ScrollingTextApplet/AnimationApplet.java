import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

//
// AnimationApplet
//
// By David Reilly
// Last modified : January 5, 1998
//
// AnimationApplet displays simple animation, generated
// by an animation thread. This applet is an example from
// "Unravelling threads"
//
//

public class AnimationApplet extends JApplet implements Runnable
{
	// Reference to animation thread    
	private Thread AnimationThread = null;

	// String for text scrolling (DEFAULT VALUE)
	private String m_AnimationString = "Welcome to my web page";

	// Name of parameter
	private final String PARAM_AnimationString = "AnimationString";

	// Buffered graphics display
	private Image bufferedDisplay = null;

	// Boolean flag to see whether animation should continue
	private boolean animate = true;

	// AnimationApplet Constructor
	public AnimationApplet()
	{
		// TODO: Add constructor code here
	}

	public String getAppletInfo()
	{
		return "Name: AnimationApplet\r\n" + "Author: David Reilly\r\n"
				+ "Created with Microsoft Visual J++ Version 1.1\n"
				+ "Changed by JiM for swing";
	}

	// Return a list of parameters
	public String[][] getParameterInfo()
	{
		String[][] info =
		{
		{ PARAM_AnimationString, "String", "String to be animated" }, };
		return info;
	}

	// Init method for applet initialization
	public void init()
	{
		String param;

		// Get parameter or use default if none present
		param = getParameter(PARAM_AnimationString);
		if (param != null)
			m_AnimationString = param;

		// Resize applet if we're in appletviewer
		resize(500, 250);

		// Get an image for offscreen drawing
		bufferedDisplay = createImage(500, 250);
	}

	public void update(Graphics g)
	{
		paint(g);
	}

	// Paint handler, called when applet display is updated
	public void paint(Graphics g)
	{
		if (bufferedDisplay != null)
			g.drawImage(bufferedDisplay, 0, 0, null);
	}

	// Start method when applet is displayed in browser, or page reloaded
	public void start()
	{
		// Check to see if thread is active
		if (AnimationThread == null)
		{
			// Pass our thread an instance of java.lang.Runnable (us)
			AnimationThread = new Thread(this);

			// Start the thread (new thread executes public void run() method
			AnimationThread.start();
		}
	}

	// Stop method invoked when page containing applet not visible
	public void stop()
	{
		// If animation thread running....
		if (AnimationThread != null)
		{
			// Clear our reference to the thread, for automated garbage collection
			AnimationThread = null;
		}

		// TODO: Place additional applet stop code here
	}

	// Thread code execution starts here
	public void run()
	{
		// Get dimensions of the applet     
		int width = getWidth();
		int height = getHeight();

		// Offset for text message (start offscreen)
		int xOffset = width + 15;
		int yOffset = height / 2;

		// Get an instance of java.awt.Graphics to draw on image
		Graphics display = bufferedDisplay.getGraphics();

		// Set font for display
		Font textFont = new Font("Arial", Font.BOLD, 20);
		display.setFont(textFont);

		// Get width of text string
		FontMetrics fm = display.getFontMetrics();
		int strWidth = fm.stringWidth(m_AnimationString);

		while (true)
		{
			try
			{
				if (animate == false)
				{
					Thread.sleep(1000);
					continue;
				}

				// Clear display to black
				display.setColor(Color.black);
				display.fillRect(0, 0, width, height);

				// Now draw text
				display.setColor(Color.YELLOW);
				display.drawString(m_AnimationString, xOffset, yOffset);

				// Decrement xOffset for scrolling effect
				xOffset--;

				if (xOffset < -strWidth)
					xOffset = width + 1;

				repaint();
				Thread.sleep(10);

			}
			catch (InterruptedException e)
			{
				stop();
			}
		}
	}

	protected void processMouseEvent(MouseEvent evt)
	{
		if (evt.getID() == MouseEvent.MOUSE_PRESSED)
		{
			// Suspend animation
			animate = false;
		}
		else
		{
			// Resume animation
			animate = true;
		}
	}
}
