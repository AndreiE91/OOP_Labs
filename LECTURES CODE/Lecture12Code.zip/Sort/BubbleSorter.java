// "Java Tech"
//  Code provided with book for educational purposes only.
//  No warranty or guarantee implied.
//  This code freely available. No copyright claimed.
//  2003
//

/**
  * Use a simple Bubble Sort to sort either an integer
  * or double array. Extends abstract Thread subclass Sorter
  * so it provides a run () method.
 **/
public class BubbleSorter extends Sorter
{

  /** Sort integer data array. **/
  public BubbleSorter (Updateable owner, int [] data) {
    fOwner = owner;
    fIdata = data;
  } // ctor

  /** Sort double data array. **/
  public BubbleSorter (Updateable owner, double [] data) {
    fOwner = owner;
    fDdata = data;
  } // ctor

  public void run () {
    if (fIdata != null)
        sort (fIdata);
    else
        sort (fDdata);
  } // run

  /** Sort an int array. **/
  public void sort (int data[]) {
    for (int i = data.length-1; i >= 0 ; i--) {
        boolean swapped = false;
        for (int j = 0; j < i; j++) {
            if (fStop) {
                fOwner.done ();
                return;
            }
            if (data[j] > data[j+1]) {
                int tmp = data[j];
                data[j] = data[j+1];
                data[j+1] = tmp;
                swapped = true;
            }
            fOwner.update (this);
        }
        if  (!swapped) break;
    }
    fOwner.done ();

  } // sort (int data [])

  // Sort a double array. **/
  public void sort (double data[]) {
    for (int i = 0; i < data.length; i++) {
        boolean swapped = false;
        for (int j = 0; j < i; j++) {
            if (fStop) {
                fOwner.done ();
                return;
            }
            if ( data[j] > data[j+1]) {
            double tmp = data[j];
            data[j] = data[j+1];
            data[j+1] = tmp;
            swapped = true;
        }
        fOwner.update (this);
      }
      if  (!swapped) break;
    }
    fOwner.done ();
  } // sort (double data [])

} //class BubbleSorter