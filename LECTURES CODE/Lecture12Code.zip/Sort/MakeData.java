// "Java Tech"
//  Code provided with book for educational purposes only.
//  No warranty or guarantee implied.
//  This code freely available. No copyright claimed.
//  2003
//

/**
  * This runnable class fills a histogram with Gaussian
  * distributed random data.
 **/
public class MakeData implements Runnable
{
  Histogram fHistogram;
  int fNumData;
  Updateable fOwner;

  // Gaussian center with default value
  double fSignalPoint;

  // Flat background range with defaults
  double fBgLow;
  double fBgRange;

  // Fraction of the data due to the Gaussian
  double fFractionSignal = 0.60;

  // Maximum delay between data points with default
  int fMaxDelay = 1000;

  // Create an instance of the Random class for
  // producing our random values.
  static java.util.Random fRan = new java.util.Random ();

/**
  *  Constructor
  *  @param owner to call back with updates.
  *  @param histogram to add data to.
  *  @param numData Number of data points to add to histogram.
  *  @param signalPoint Position of center of Gaussian.
  *  @param fractionSignal Fraction of data due to Gaussian
  *  @param bgLow Low end of flat background range.
  *  @param bgHi High end of flat background range.
  *  @param maxDelay maximum delay in msecs between data events.
 **/
 public MakeData (Updateable owner,
           Histogram histogram, int numData,
           double fSignalPoint, double fractionSignal,
           double bgLow, double bgHi,
           int maxDelay) {

    fHistogram  = histogram;
    fNumData    = numData;
    fOwner = owner;

    // Background upper and lower range
    fBgLow   = bgLow;
    fBgRange = bgHi - fBgLow;

    // Position of center of Gaussian.
    fSignalPoint    = fSignalPoint;
    fFractionSignal = fractionSignal;

    // Maximum delay time between new data points
    fMaxDelay = maxDelay;
  } // ctor


  /**
    * Simulate data taking by generating both a Gaussian
    * and a flat background. Put in random delays between
    * the data points.
   **/
  public void run () {
    for (int i=0; i < fNumData; i++) {
        double val;

        // Signal events
        if (fRan.nextDouble () < fFractionSignal)
            val = fRan.nextGaussian () + fSignalPoint;
        else
        // Flat background
            val = fBgRange * fRan.nextFloat () + fBgLow;

        // Fill histogram
        fHistogram.add (val);

        // Update the owner. Stop updates if
        // false returned.
        if (!fOwner.update (this) ) break;

        // Pause for random periods between events
        try {
          Thread.sleep (fRan.nextInt (fMaxDelay));
        }
        catch  (InterruptedException e)
        {}
    }

    // Tell the Updateable owner that the fNumData is now filled.
    fOwner.done ();
  } // run

} // class MakeData

