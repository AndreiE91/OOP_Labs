// "Java Tech"
//  Code provided with book for educational purposes only.
//  No warranty or guarantee implied.
//  This code freely available. No copyright claimed.
//  2003
//

/**
  * An abstract class used as a base class for
  * sort algorithm classes.
 **/
public abstract class Sorter extends Thread
{
  boolean fStop = false;
  Updateable fOwner = null;
  int [] fIdata = null;
  double [] fDdata = null;

  public void setStop ()
  { fStop = true;}

  public abstract void sort (int data[]);
  public abstract void sort (double data[]);

} // class Sorter
