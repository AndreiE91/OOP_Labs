
// "Java Tech"
//  Code provided with book for educational purposes only.
//  No warranty or guarantee implied.
//  This code freely available. No copyright claimed.
//  2003
//

/**
  * This interface provides for callbacks to
  * update an object.
 **/
interface Updateable
{
  boolean update (Object obj);
  void done ();
} // interface Updateable