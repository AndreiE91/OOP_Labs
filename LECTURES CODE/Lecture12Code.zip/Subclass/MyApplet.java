// "Java Tech"
//  Code provided with book for educational purposes only.
//  No warranty or guarantee implied.
//  This code freely available. No copyright claimed.
//  2003
//

/*
<applet code="MyApplet.class" width=300 height=300>
</applet>
 */
import javax.swing.JLabel;
import javax.swing.BoxLayout;

/** Demo of threading with a Thread subclass.**/
public class MyApplet extends javax.swing.JApplet {
    private String message;
    private int x;
    private int y;
    String blanks = "                                    ";
    //   private java.awt.FontMetrics fm;
    //   private java.awt.Graphics g;
    private JLabel labels[];
    public void init() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        labels = new JLabel[4];
        for (int i=0; i < labels.length; i++)
        {
            labels[i]= new JLabel(blanks);
            add(labels[i]);
        }
    }
    /** Applet's start method creates and starts a thread.**/
    public void start () {

        MyThread thArray[] = new MyThread[labels.length];
        // Create instances of MyThread.
        for (int i=0; i < thArray.length; i++)
            thArray[i] = new MyThread (this, i + 1);
        //  fm = getFontMetrics(getFont());

        // Start the threads
        for (int i=0; i < thArray.length; i++)
            thArray[i].start ();
    }
    //   public void paintMessage(String message, int x, int y)
    //   {
    //       this.x = x;
    //       this.y = y;
    //       this.message = message;
    // //       java.awt.geom.Rectangle2D r=fm.getStringBounds(message, g);
    // //       g.fillRect(x, y, (int)r.getWidth(), (int)r.getHeight() );
    //       repaint();
    //   }
    public void paintMessage(String message, int lblNum)
    {
        labels[lblNum].setText(message);
        repaint();
    }
// 
//     public void paint(java.awt.Graphics g) {
//         //    g.drawString(message, x, y);
//         super.repaint();
//     }
} // class MyApplet
