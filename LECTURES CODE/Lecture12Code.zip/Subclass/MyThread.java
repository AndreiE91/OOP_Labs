// "Java Tech"
//  Code provided with book for educational purposes only.
//  No warranty or guarantee implied.
//  This code freely available. No copyright claimed.
//  2003
//

public class MyThread extends Thread {
    int thNum;
    MyApplet ref;
    public MyThread(MyApplet apRef, int num)
    {
        ref = apRef;
        thNum = num;
    }

    public void run () {
        int count = 0;

        while (true) {
            //         ref.paintMessage("                                  ", 20, thNum * 40);
            //         ref.paintMessage("Thread " + thNum + " alive", 20, thNum * 40);
            ref.paintMessage("Thread " + thNum + " alive", thNum);
            // Print every 0.10sec for 2 seconds
            try {
                Thread.sleep (500);
            } catch (InterruptedException e) {}

            count++;
            if (count >= 20) break;
        }

        //     ref.paintMessage("Thread " + thNum + " stopping", 120, thNum * 40);
        ref.paintMessage("Thread " + thNum + " stopping", thNum);
    } // run
} // class MyThread
