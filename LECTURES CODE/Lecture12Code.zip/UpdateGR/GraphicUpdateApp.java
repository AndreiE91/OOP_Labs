import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GraphicUpdateApp extends JFrame implements Runnable
{
	Thread animation;
	int frameDelay = 200;
	Image frames[];
	int numFrames;
	int currentFrame = 0;
	long lastDisplay = 0;
	boolean fullDisplay = false;
	MediaTracker tracker;
	int screenWidth = 400;
	int screenHeight = 400;

	public static void main(String args[])
	{
		GraphicUpdateApp app = new GraphicUpdateApp();
	}

	public GraphicUpdateApp()
	{
		super("Updated Graphic Animation");
		setup();
		pack();
		setSize(screenWidth, screenHeight);
		addWindowListener(new WindowEventHandler());
		setVisible(true);
		animation = new Thread(this);
		animation.start();
	}

	void setup()
	{
		setupMenuBar();
		setFont(new Font("default", Font.BOLD, 18));
		Toolkit toolkit = getToolkit();
		frames = new Image[4];
		// Load animation frames
		frames[0] = toolkit.getImage("stickman1.gif");
		frames[1] = toolkit.getImage("stickman2.gif");
		frames[2] = toolkit.getImage("stickman3.gif");
		frames[3] = toolkit.getImage("stickman4.gif");
		numFrames = frames.length;
		tracker = new MediaTracker(this);
		// Use the MediaTracker object to manage the frames
		for (int i = 0; i < numFrames; ++i)
			tracker.addImage(frames[i], i);
	}

	void setupMenuBar()
	{
		MenuBar menuBar = new MenuBar();
		Menu fileMenu = new Menu("File");
		MenuItem fileExit = new MenuItem("Exit");
		fileExit.addActionListener(new MenuItemHandler());
		fileMenu.add(fileExit);
		menuBar.add(fileMenu);
		setMenuBar(menuBar);
	}

	public void paint(Graphics g)
	{
	    Graphics2D g2 = (Graphics2D) g;
		if (allLoaded())
			g2.drawImage(frames[currentFrame], 125, 80, this);
		else
		{
			String stars = "*";
			for (int i = 0; i < currentFrame; ++i)
				stars += "*";
			g2.drawString(stars, 60, 60);
		}
	}

	boolean allLoaded()
	{
		for (int i = 0; i < numFrames; ++i)
		{
			if (tracker.statusID(i, true) != MediaTracker.COMPLETE)
				return false;
		}
		return true;
	}

	public void run()
	{
		// The animation loop
		do
		{
			long time = System.currentTimeMillis();
			if (time - lastDisplay > frameDelay)
			{
				if (allLoaded())
				{
					if (fullDisplay)
						repaint(115, 160, 160, 90);
					else
					{
						fullDisplay = true;
						repaint();
					}
				}
				else
					repaint();
				try
				{
					Thread.sleep(frameDelay);
				}
				catch (InterruptedException ex)
				{
				}
				++currentFrame;
				currentFrame %= numFrames;
				lastDisplay = time;
			}
		}
		while (true);
	}

	class MenuItemHandler implements ActionListener, ItemListener
	{
		public void actionPerformed(ActionEvent ev)
		{
			String s = ev.getActionCommand();
			if (s == "Exit")
			{
				System.exit(0);
			}
		}

		public void itemStateChanged(ItemEvent e)
		{
		}
	}

	class WindowEventHandler extends WindowAdapter
	{
		public void windowClosing(WindowEvent e)
		{
			System.exit(0);
		}
	}
}
