import java.nio.*;
import java.nio.channels.*;
import java.io.*;
// reverses bytes in a file
public class MappedBufferDemo 
{
    public static void main(String args[]) throws IOException 
    {
        // check command-line argument
        if (args.length != 1) {
            System.err.println("missing file argument");
            System.exit(1);
        }

        // get channel
        RandomAccessFile raf = new RandomAccessFile(args[0], "rw");
        FileChannel fc = raf.getChannel();

        // map file to buffer
        MappedByteBuffer mbb = fc.map(FileChannel.MapMode.READ_WRITE, 0, fc.size());

        // reverse bytes of file
 
        int len = (int)fc.size();
        for (int i = 0, j = len - 1; i < j; i++, j--) 
        {
          byte b = mbb.get(i);
          mbb.put(i, mbb.get(j));
          mbb.put(j, b);
        }
        // finish up
        fc.close();
        raf.close();
    }
}