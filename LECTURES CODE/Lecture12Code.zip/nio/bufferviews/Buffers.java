
/**
 * Write a description of class Buffers here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.nio.*;
public class Buffers {
  public static void main(String[] args)   {
     try {
         float[] floats = {
           6.612297E-39F, 9.918385E-39F, 1.0193785E-38F, 
           1.092858E-38F, 1.0469398E-38F, 9.183596E-39f
       };
        char[] chars = {'H', 'e', 'l', 'l', 'o', ' ',
            'w', 'o', 'r', 'l', 'd', '!'};
       ByteBuffer bb = 
          ByteBuffer.allocate(floats.length * 4 );
          FloatBuffer fb = bb.asFloatBuffer();
       fb.put(floats);
       CharBuffer cb = bb.asCharBuffer();
       System.out.println(cb.toString());
       //
       ByteBuffer bbb = ByteBuffer.allocate(chars.length * 2);
       CharBuffer cbb = bbb.asCharBuffer();
       cbb.put(chars);
       //FloatBuffer fbb = bbb.asFloatBuffer();
       for (int i=0; i < 6; i++)
        System.out.println( (i+1) + " " + bbb.getFloat());
    } catch (Exception e) {
       System.out.println(e.getMessage());
       e.printStackTrace();
    }
  }
}