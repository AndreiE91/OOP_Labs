import java.nio.*;
import java.nio.channels.*;
import java.io.*;
// copies a file to another
public class DirectChannelTransferDemo{
    public static void main(String args[]) 
                               throws IOException {

        // check command-line arguments

        if (args.length != 2) {
            System.err.println("missing filenames");
            System.exit(1);
        }

        // get channels

        FileInputStream fis = new FileInputStream(args[0]);
        FileOutputStream fos = new FileOutputStream(args[1]);
        FileChannel fcin = fis.getChannel();
        FileChannel fcout = fos.getChannel();

        // do the file copy

        fcin.transferTo(0, fcin.size(), fcout);

        // finish up

        fcin.close();
        fcout.close();
        fis.close();
        fos.close();
    }
}