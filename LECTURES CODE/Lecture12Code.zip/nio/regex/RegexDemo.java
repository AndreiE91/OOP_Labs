import java.io.*;
import java.nio.*;
import java.nio.channels.FileChannel;
/**
 * Write a description of class RegexDemo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RegexDemo
{
    // instance variables - replace the example below with your own
    public static final String VALID_EMAIL_PATTERN = 
    "([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]" + 
    "{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))" + 
    "([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)"; 
    /**
     * Constructor for objects of class RegexDemo
     */
    public static void analyzeAddresses( String s ) 
    {
        if (s.matches (VALID_EMAIL_PATTERN)) 
        { 
            System.out.println( s + " " + "Okay.");
        } 
        else 
        { 
            throw new IllegalArgumentException ( s ); 
        }
    }
    public static void main(String[] args)
    {
        FileInputStream fi = null;
        try
        {
            fi = new FileInputStream(args[0]);
            FileChannel fc = fi.getChannel();
            // for small files can read all contents
            ByteBuffer bb = ByteBuffer.allocate((int)fc.size());
            fc.read( bb );
            // create string from buffer contents
            String s = new String( bb.array() ); 
            // split to whitespace
            String[] tokens = s.split("\\s");
            for (int i = 0; i < tokens.length; i++)
            {
                try
                {
                    if (tokens[i].length() > 0) 
                        analyzeAddresses( tokens[i] );
                }
                catch ( IllegalArgumentException e )
                {
                    System.err.println("At line " + i + ": " + 
                        e + " Bad address format.");
                }
            }
        }
        catch (FileNotFoundException ef)
        {
            System.out.println("File not found.");
            System.exit(1);
        }
        catch (IOException e)
        {
            e.printStackTrace();
            System.exit(2);
        }
        finally
        {
            try
            {
                if (fi != null) fi.close();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }
}
