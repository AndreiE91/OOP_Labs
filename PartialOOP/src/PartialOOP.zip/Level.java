public enum Level {
    JUNIOR,
    MID,
    SENIOR
}
